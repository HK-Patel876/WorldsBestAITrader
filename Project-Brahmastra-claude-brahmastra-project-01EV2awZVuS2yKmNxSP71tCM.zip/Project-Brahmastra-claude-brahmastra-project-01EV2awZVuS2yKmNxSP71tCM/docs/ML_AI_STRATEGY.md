# Project Brahmastra - ML/AI Strategy

**Version:** 1.0
**Last Updated:** 2025-11-16

---

## Table of Contents
1. [ML/AI Vision](#mlai-vision)
2. [Model Architecture](#model-architecture)
3. [Training Pipeline](#training-pipeline)
4. [Feature Engineering](#feature-engineering)
5. [Model Types](#model-types)
6. [Deployment Strategy](#deployment-strategy)
7. [Monitoring & Retraining](#monitoring--retraining)
8. [AutoML Integration](#automl-integration)

---

## ML/AI Vision

### Objectives
1. **Adaptive Learning**: Models that continuously learn from market behavior
2. **Multi-Model Ensemble**: Combine multiple models for robust predictions
3. **Explainability**: Understand model decisions (XAI)
4. **Real-time Inference**: Sub-100ms prediction latency
5. **AutoML**: Automated model selection and hyperparameter tuning

### Inspiration from 10 Repos

| Repository | ML Approach | Key Learnings |
|------------|-------------|---------------|
| **Freqtrade FreqAI** | Adaptive prediction modeling | Continuous retraining, model per pair |
| **Qlib** | Full ML pipeline | Alpha seeking, multi-paradigm support |
| **AlphaPy** | AutoML | Multiple ML libraries, ensemble methods |
| **Jesse** | AI assistant | Strategy optimization |
| **VectorBT** | Vectorized backtest | Fast parameter optimization |

---

## Model Architecture

### Three-Tier Model System

```
┌─────────────────────────────────────────────────────────┐
│                    Tier 1: Prediction Models            │
│         (Price, Direction, Volatility Forecasting)      │
├─────────────────────────────────────────────────────────┤
│                    Tier 2: Signal Models                │
│           (Entry/Exit Signals, Confidence Scores)       │
├─────────────────────────────────────────────────────────┤
│                  Tier 3: Strategy Selection             │
│         (Meta-Learning, Strategy Recommendation)        │
└─────────────────────────────────────────────────────────┘
```

### Model Hierarchy

```python
class ModelHierarchy:
    """
    Three-tier model system for trading decisions
    """

    # Tier 1: Price Prediction Models
    price_models = {
        'lstm': LSTMPricePredictor(),
        'transformer': TransformerPredictor(),
        'xgboost': XGBoostRegressor(),
        'ensemble': EnsemblePredictor()
    }

    # Tier 2: Signal Generation Models
    signal_models = {
        'classification': SignalClassifier(),  # Buy/Sell/Hold
        'regression': SignalStrength(),        # Signal strength 0-1
        'rl_agent': DQNAgent()                # RL for sequential decisions
    }

    # Tier 3: Meta-Learning
    meta_learner = StrategySelector()  # Selects best strategy for conditions
```

---

## Training Pipeline

### Pipeline Architecture

```
Data Collection → Feature Engineering → Train/Val Split → Model Training
                                                              ↓
Performance Monitoring ← Model Deployment ← Model Validation ← Hyperparameter Tuning
```

### Training Workflow

```python
class MLTrainingPipeline:
    """
    Automated ML training pipeline
    Inspired by: Qlib, FreqAI, AlphaPy
    """

    def train_model(self, symbol: str, timeframe: str):
        """
        Complete training pipeline for a single model
        """
        # 1. Data Collection
        data = self.collect_data(symbol, timeframe)

        # 2. Feature Engineering
        features = self.engineer_features(data)

        # 3. Train/Validation Split
        X_train, X_val, y_train, y_val = self.split_data(features)

        # 4. Hyperparameter Optimization
        best_params = self.optimize_hyperparameters(X_train, y_train)

        # 5. Model Training
        model = self.train(X_train, y_train, best_params)

        # 6. Validation
        metrics = self.validate(model, X_val, y_val)

        # 7. Model Registry
        if metrics['sharpe'] > 1.5:  # Quality threshold
            self.register_model(model, metrics)

        # 8. Deployment
        if self.should_deploy(metrics):
            self.deploy_model(model)

        return model, metrics
```

### Training Schedule

| Frequency | Model Type | Trigger |
|-----------|------------|---------|
| **Every 5 minutes** | RL Agents | Continuous learning |
| **Every hour** | Short-term predictors | Market regime changes |
| **Daily** | Medium-term models | End of day |
| **Weekly** | Long-term models | Strategy evaluation |
| **On-demand** | All models | Performance degradation |

---

## Feature Engineering

### Feature Categories

#### 1. Technical Indicators (300+)

```python
class TechnicalFeatures:
    """
    Technical indicator features
    Inspired by: TA-Lib, Backtrader
    """

    # Trend Indicators
    trend_features = [
        'SMA_10', 'SMA_20', 'SMA_50', 'SMA_200',
        'EMA_10', 'EMA_20', 'EMA_50',
        'MACD', 'MACD_signal', 'MACD_hist',
        'ADX', 'DI_plus', 'DI_minus'
    ]

    # Momentum Indicators
    momentum_features = [
        'RSI_14', 'RSI_21',
        'Stochastic_K', 'Stochastic_D',
        'CCI', 'ROC', 'MOM'
    ]

    # Volatility Indicators
    volatility_features = [
        'BB_upper', 'BB_middle', 'BB_lower', 'BB_width',
        'ATR', 'Keltner_upper', 'Keltner_lower',
        'Donchian_upper', 'Donchian_lower'
    ]

    # Volume Indicators
    volume_features = [
        'OBV', 'VWAP', 'MFI',
        'Volume_SMA', 'Volume_ratio'
    ]
```

#### 2. Price-Based Features

```python
class PriceFeatures:
    """
    Raw and derived price features
    """

    def create_features(self, df):
        # Returns
        df['return_1'] = df['close'].pct_change(1)
        df['return_5'] = df['close'].pct_change(5)
        df['return_20'] = df['close'].pct_change(20)

        # Volatility
        df['volatility_20'] = df['return_1'].rolling(20).std()

        # Price ratios
        df['high_low_ratio'] = df['high'] / df['low']
        df['close_open_ratio'] = df['close'] / df['open']

        # Gaps
        df['gap'] = (df['open'] - df['close'].shift(1)) / df['close'].shift(1)

        return df
```

#### 3. Order Book Features

```python
class OrderBookFeatures:
    """
    Order book imbalance and depth features
    Inspired by: Hummingbot
    """

    def calculate_features(self, orderbook):
        # Bid-Ask Spread
        spread = orderbook['ask_price_1'] - orderbook['bid_price_1']

        # Order Book Imbalance
        bid_volume = orderbook[['bid_volume_1', 'bid_volume_2', 'bid_volume_3']].sum()
        ask_volume = orderbook[['ask_volume_1', 'ask_volume_2', 'ask_volume_3']].sum()
        imbalance = (bid_volume - ask_volume) / (bid_volume + ask_volume)

        # Depth
        mid_price = (orderbook['ask_price_1'] + orderbook['bid_price_1']) / 2
        depth = (orderbook['ask_volume_1'] + orderbook['bid_volume_1']) / mid_price

        return {
            'spread': spread,
            'imbalance': imbalance,
            'depth': depth
        }
```

#### 4. Sentiment Features

```python
class SentimentFeatures:
    """
    News and social media sentiment
    """

    def extract_sentiment(self, text):
        # NLP-based sentiment analysis
        from transformers import pipeline

        sentiment_analyzer = pipeline('sentiment-analysis',
                                     model='finbert-tone')

        result = sentiment_analyzer(text)

        return {
            'sentiment_score': result[0]['score'],
            'sentiment_label': result[0]['label']  # positive/negative/neutral
        }
```

#### 5. Market Regime Features

```python
class MarketRegimeFeatures:
    """
    Identify market regimes using HMM or clustering
    """

    def identify_regime(self, df):
        from hmmlearn import hmm

        # Features for regime detection
        features = df[['volatility', 'trend_strength', 'volume']].values

        # Hidden Markov Model
        model = hmm.GaussianHMM(n_components=3)  # Bull, Bear, Sideways
        model.fit(features)

        df['regime'] = model.predict(features)
        # 0 = Bull, 1 = Bear, 2 = Sideways

        return df
```

### Feature Selection

```python
class FeatureSelector:
    """
    Automated feature selection
    Inspired by: AlphaPy
    """

    def select_features(self, X, y, method='all'):
        selected_features = []

        # 1. Correlation-based
        if method in ['correlation', 'all']:
            selected_features.extend(
                self.select_by_correlation(X, y)
            )

        # 2. Importance-based (Random Forest)
        if method in ['importance', 'all']:
            selected_features.extend(
                self.select_by_importance(X, y)
            )

        # 3. Recursive Feature Elimination
        if method in ['rfe', 'all']:
            selected_features.extend(
                self.select_by_rfe(X, y)
            )

        # 4. L1 Regularization (Lasso)
        if method in ['lasso', 'all']:
            selected_features.extend(
                self.select_by_lasso(X, y)
            )

        return list(set(selected_features))
```

---

## Model Types

### 1. LSTM (Long Short-Term Memory)

**Use Case**: Time series prediction, sequence modeling

```python
class LSTMPricePredictor:
    """
    LSTM model for price prediction
    Inspired by: Qlib, AlphaPy
    """

    def __init__(self, seq_length=60, features=10):
        self.model = Sequential([
            LSTM(128, return_sequences=True, input_shape=(seq_length, features)),
            Dropout(0.2),
            LSTM(64, return_sequences=True),
            Dropout(0.2),
            LSTM(32),
            Dropout(0.2),
            Dense(16, activation='relu'),
            Dense(1)  # Price prediction
        ])

        self.model.compile(
            optimizer='adam',
            loss='huber',  # Robust to outliers
            metrics=['mae', 'mse']
        )

    def train(self, X_train, y_train, epochs=100):
        early_stop = EarlyStopping(
            monitor='val_loss',
            patience=10,
            restore_best_weights=True
        )

        self.model.fit(
            X_train, y_train,
            epochs=epochs,
            batch_size=32,
            validation_split=0.2,
            callbacks=[early_stop],
            verbose=1
        )
```

### 2. Transformer

**Use Case**: Long-range dependencies, multi-variate time series

```python
class TransformerPredictor:
    """
    Transformer model for market prediction
    State-of-the-art for time series
    """

    def __init__(self, seq_length=60, d_model=128, nhead=8):
        # Positional Encoding
        self.pos_encoder = PositionalEncoding(d_model)

        # Transformer Encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=512,
            dropout=0.1
        )

        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=6
        )

        # Output layer
        self.fc = nn.Linear(d_model, 1)

    def forward(self, x):
        x = self.pos_encoder(x)
        x = self.transformer(x)
        x = self.fc(x[:, -1, :])  # Last time step
        return x
```

### 3. XGBoost

**Use Case**: Feature-rich classification/regression, fast training

```python
class XGBoostSignalClassifier:
    """
    XGBoost for trading signal classification
    Inspired by: AlphaPy
    """

    def __init__(self):
        self.model = xgb.XGBClassifier(
            n_estimators=500,
            max_depth=10,
            learning_rate=0.01,
            subsample=0.8,
            colsample_bytree=0.8,
            objective='multi:softprob',  # Buy/Sell/Hold
            num_class=3,
            eval_metric='mlogloss',
            early_stopping_rounds=50
        )

    def train(self, X_train, y_train, X_val, y_val):
        self.model.fit(
            X_train, y_train,
            eval_set=[(X_val, y_val)],
            verbose=True
        )

        # Feature importance
        self.plot_feature_importance()

    def predict_proba(self, X):
        """
        Returns probability for each class
        [P(Sell), P(Hold), P(Buy)]
        """
        return self.model.predict_proba(X)
```

### 4. Reinforcement Learning

**Use Case**: Sequential decision making, adaptive strategies

```python
class TradingDQNAgent:
    """
    Deep Q-Network for trading
    Inspired by: Stable-Baselines3
    """

    def __init__(self, state_dim, action_dim):
        # Q-Network
        self.q_network = nn.Sequential(
            nn.Linear(state_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, action_dim)  # Q-values for each action
        )

        # Target Network
        self.target_network = copy.deepcopy(self.q_network)

        # Replay Buffer
        self.replay_buffer = ReplayBuffer(capacity=100000)

        # Actions: [Sell, Hold, Buy]
        self.actions = [-1, 0, 1]

    def select_action(self, state, epsilon=0.1):
        """
        Epsilon-greedy action selection
        """
        if random.random() < epsilon:
            return random.choice(self.actions)  # Explore
        else:
            with torch.no_grad():
                q_values = self.q_network(state)
                return self.actions[q_values.argmax()]  # Exploit

    def train_step(self, batch_size=64):
        """
        Train on a batch from replay buffer
        """
        states, actions, rewards, next_states, dones = \
            self.replay_buffer.sample(batch_size)

        # Current Q-values
        current_q = self.q_network(states).gather(1, actions)

        # Target Q-values
        with torch.no_grad():
            next_q = self.target_network(next_states).max(1)[0]
            target_q = rewards + (1 - dones) * 0.99 * next_q

        # Loss
        loss = F.mse_loss(current_q.squeeze(), target_q)

        # Backpropagation
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return loss.item()
```

### 5. Ensemble Models

**Use Case**: Combine multiple models for robustness

```python
class EnsemblePredictor:
    """
    Ensemble of multiple models
    Inspired by: AlphaPy, VectorBT
    """

    def __init__(self):
        self.models = {
            'lstm': LSTMPricePredictor(),
            'xgboost': XGBoostRegressor(),
            'lightgbm': LGBMRegressor(),
            'random_forest': RandomForestRegressor()
        }

        self.weights = None  # Learned weights

    def train(self, X_train, y_train, X_val, y_val):
        """
        Train all base models
        """
        predictions = {}

        for name, model in self.models.items():
            model.fit(X_train, y_train)
            predictions[name] = model.predict(X_val)

        # Learn optimal weights using validation data
        self.weights = self.optimize_weights(predictions, y_val)

    def predict(self, X):
        """
        Weighted average of predictions
        """
        predictions = np.array([
            model.predict(X) for model in self.models.values()
        ])

        return np.average(predictions, axis=0, weights=self.weights)
```

---

## Deployment Strategy

### Model Serving Architecture

```
API Request → Load Balancer → Model Server → Inference Engine
                                  ↓
                          Model Registry (MLflow/BentoML)
                                  ↓
                          Prediction Cache (Redis)
```

### Deployment Methods

#### 1. REST API (Batch Predictions)

```python
@app.post("/predict")
async def predict(request: PredictionRequest):
    """
    Batch prediction endpoint
    """
    # Load model from registry
    model = mlflow.sklearn.load_model(f"models:/{request.model_name}/production")

    # Prepare features
    features = prepare_features(request.data)

    # Predict
    predictions = model.predict(features)

    return {"predictions": predictions.tolist()}
```

#### 2. Streaming (Real-time)

```python
class StreamingPredictor:
    """
    Real-time predictions from streaming data
    """

    def __init__(self):
        self.model = load_model("lstm_btc_v1")
        self.feature_buffer = deque(maxlen=60)  # Last 60 candles

    async def on_candle(self, candle):
        """
        Called for each new candle
        """
        # Add to buffer
        self.feature_buffer.append(candle)

        if len(self.feature_buffer) == 60:
            # Prepare features
            X = self.prepare_features(self.feature_buffer)

            # Predict
            prediction = self.model.predict(X)

            # Emit prediction
            await self.emit_prediction(prediction)
```

---

## Monitoring & Retraining

### Model Monitoring

```python
class ModelMonitor:
    """
    Monitor model performance in production
    Inspired by: Qlib, FreqAI
    """

    def monitor_model(self, model_id, predictions, actuals):
        """
        Track model performance metrics
        """
        # Prediction accuracy
        mae = mean_absolute_error(actuals, predictions)
        rmse = root_mean_squared_error(actuals, predictions)
        r2 = r2_score(actuals, predictions)

        # Directional accuracy
        pred_direction = np.sign(predictions)
        actual_direction = np.sign(actuals)
        direction_accuracy = (pred_direction == actual_direction).mean()

        # Log to InfluxDB
        self.log_metrics(model_id, {
            'mae': mae,
            'rmse': rmse,
            'r2': r2,
            'direction_accuracy': direction_accuracy
        })

        # Alert if performance degrades
        if direction_accuracy < 0.55:  # Threshold
            self.alert_model_degradation(model_id)
```

### Concept Drift Detection

```python
class DriftDetector:
    """
    Detect data/concept drift
    """

    def detect_drift(self, reference_data, current_data):
        """
        Detect distribution shift using KL-divergence
        """
        from scipy.stats import entropy

        # Calculate distributions
        ref_dist = self.calculate_distribution(reference_data)
        curr_dist = self.calculate_distribution(current_data)

        # KL Divergence
        kl_div = entropy(ref_dist, curr_dist)

        # Alert if drift detected
        if kl_div > 0.1:  # Threshold
            self.trigger_retraining()

        return kl_div
```

### Automated Retraining

```python
class AutoRetrainer:
    """
    Automated model retraining
    Inspired by: FreqAI
    """

    def should_retrain(self, model_id):
        """
        Decide if model should be retrained
        """
        criteria = {
            'performance_degraded': self.check_performance(model_id),
            'drift_detected': self.check_drift(model_id),
            'scheduled': self.check_schedule(model_id),
            'new_data_available': self.check_new_data(model_id)
        }

        return any(criteria.values())

    async def retrain_model(self, model_id):
        """
        Retrain model with latest data
        """
        # Fetch latest data
        data = await self.fetch_training_data()

        # Train new model
        new_model = await self.train_pipeline.train(data)

        # Validate
        metrics = await self.validate_model(new_model)

        # A/B test: Compare with current model
        if metrics['sharpe'] > self.get_current_metrics(model_id)['sharpe']:
            # Deploy new model
            await self.deploy_model(new_model)
```

---

## AutoML Integration

### Hyperparameter Optimization

```python
import optuna

class AutoMLOptimizer:
    """
    Automated hyperparameter optimization
    Inspired by: AlphaPy, Optuna
    """

    def optimize_xgboost(self, X_train, y_train, X_val, y_val):
        """
        Find best XGBoost hyperparameters
        """
        def objective(trial):
            params = {
                'n_estimators': trial.suggest_int('n_estimators', 100, 1000),
                'max_depth': trial.suggest_int('max_depth', 3, 15),
                'learning_rate': trial.suggest_float('learning_rate', 0.001, 0.1, log=True),
                'subsample': trial.suggest_float('subsample', 0.6, 1.0),
                'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
                'gamma': trial.suggest_float('gamma', 0, 5),
                'reg_alpha': trial.suggest_float('reg_alpha', 0, 5),
                'reg_lambda': trial.suggest_float('reg_lambda', 0, 5)
            }

            model = xgb.XGBRegressor(**params)
            model.fit(X_train, y_train)

            predictions = model.predict(X_val)
            sharpe = self.calculate_sharpe(y_val, predictions)

            return sharpe

        study = optuna.create_study(direction='maximize')
        study.optimize(objective, n_trials=100, n_jobs=-1)

        return study.best_params
```

---

## Summary

This ML/AI strategy provides:

✅ **Adaptive Learning**: Continuous model retraining
✅ **Multi-Model Approach**: Ensemble for robustness
✅ **Comprehensive Features**: 300+ technical + alternative data
✅ **Production-Ready**: Monitoring, deployment, A/B testing
✅ **AutoML**: Automated optimization and selection
✅ **State-of-the-Art**: LSTM, Transformers, RL agents
✅ **Explainability**: Feature importance, SHAP values

Incorporates best practices from FreqAI, Qlib, AlphaPy, and modern ML/AI research.
