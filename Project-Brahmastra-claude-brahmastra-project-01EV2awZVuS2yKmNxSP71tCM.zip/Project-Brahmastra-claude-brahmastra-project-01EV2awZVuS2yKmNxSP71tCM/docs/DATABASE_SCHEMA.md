# Project Brahmastra - Database Schema

**Version:** 1.0
**Last Updated:** 2025-11-16

---

## Database Strategy: Polyglot Persistence

We use different databases optimized for specific data types:

| Database | Purpose | Data Types |
|----------|---------|------------|
| **PostgreSQL** | Primary relational | Users, strategies, trades, orders |
| **TimescaleDB** | Time-series data | OHLCV bars, ticks, metrics |
| **Redis** | Cache & real-time | Sessions, quotes, leaderboards |
| **MongoDB** | Document storage | Strategy configs, logs |
| **S3/MinIO** | Object storage | Backtest results, models |

---

## PostgreSQL Schema

### Core Tables

#### users

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    role VARCHAR(20) DEFAULT 'user',  -- user, premium, admin
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE,

    -- Trading preferences
    default_risk_per_trade DECIMAL(5, 4) DEFAULT 0.02,
    max_open_positions INTEGER DEFAULT 5,
    total_capital DECIMAL(20, 2),

    -- Indexes
    CONSTRAINT users_email_check CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$')
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_created_at ON users(created_at);
```

#### api_keys

```sql
CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    key_hash VARCHAR(255) NOT NULL,
    permissions JSONB DEFAULT '{}',  -- {"read": true, "trade": false}
    is_active BOOLEAN DEFAULT true,
    expires_at TIMESTAMP WITH TIME ZONE,
    last_used_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_api_keys_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_api_keys_user ON api_keys(user_id);
CREATE INDEX idx_api_keys_hash ON api_keys(key_hash);
```

#### exchanges

```sql
CREATE TABLE exchanges (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,  -- binance, coinbase, alpaca
    type VARCHAR(20) NOT NULL,  -- crypto, stock, forex
    is_active BOOLEAN DEFAULT true,
    api_url VARCHAR(255),
    websocket_url VARCHAR(255),
    rate_limits JSONB,  -- {"rest": 1200, "websocket": 100}
    supported_order_types JSONB,  -- ["market", "limit", "stop_loss"]
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_exchanges_name ON exchanges(name);
```

#### user_exchange_credentials

```sql
CREATE TABLE user_exchange_credentials (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exchange_id INTEGER NOT NULL REFERENCES exchanges(id),
    api_key_encrypted TEXT NOT NULL,
    api_secret_encrypted TEXT NOT NULL,
    passphrase_encrypted TEXT,  -- For exchanges like Coinbase
    is_active BOOLEAN DEFAULT true,
    is_paper_trading BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(user_id, exchange_id)
);

CREATE INDEX idx_user_exchange_creds_user ON user_exchange_credentials(user_id);
```

#### strategies

```sql
CREATE TABLE strategies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,  -- ma_crossover, rsi, ml_lstm, rl_dqn
    status VARCHAR(20) DEFAULT 'draft',  -- draft, testing, live, paused, archived

    -- Strategy configuration
    config JSONB NOT NULL,  -- Strategy parameters
    timeframe VARCHAR(10),  -- 1m, 5m, 1h, 1d
    symbols TEXT[],  -- Array of symbols

    -- Performance metrics
    total_trades INTEGER DEFAULT 0,
    winning_trades INTEGER DEFAULT 0,
    total_pnl DECIMAL(20, 2) DEFAULT 0,
    sharpe_ratio DECIMAL(10, 4),
    max_drawdown DECIMAL(10, 4),

    -- Risk management
    max_position_size DECIMAL(20, 2),
    stop_loss_pct DECIMAL(5, 4),
    take_profit_pct DECIMAL(5, 4),

    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    activated_at TIMESTAMP WITH TIME ZONE,
    deactivated_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_strategies_user ON strategies(user_id);
CREATE INDEX idx_strategies_status ON strategies(status);
CREATE INDEX idx_strategies_type ON strategies(type);
CREATE INDEX idx_strategies_created_at ON strategies(created_at);
```

#### orders

```sql
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    strategy_id UUID REFERENCES strategies(id),
    exchange_id INTEGER NOT NULL REFERENCES exchanges(id),

    -- Order details
    exchange_order_id VARCHAR(100),  -- Exchange's order ID
    symbol VARCHAR(20) NOT NULL,
    side VARCHAR(10) NOT NULL,  -- buy, sell
    type VARCHAR(20) NOT NULL,  -- market, limit, stop_loss, stop_limit
    status VARCHAR(20) NOT NULL,  -- pending, open, filled, partially_filled, cancelled, rejected

    -- Quantities and prices
    quantity DECIMAL(20, 8) NOT NULL,
    filled_quantity DECIMAL(20, 8) DEFAULT 0,
    price DECIMAL(20, 8),  -- Limit price
    stop_price DECIMAL(20, 8),  -- Stop price
    average_fill_price DECIMAL(20, 8),

    -- Fees
    fee DECIMAL(20, 8) DEFAULT 0,
    fee_currency VARCHAR(10),

    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    submitted_at TIMESTAMP WITH TIME ZONE,
    filled_at TIMESTAMP WITH TIME ZONE,
    cancelled_at TIMESTAMP WITH TIME ZONE,

    -- Additional info
    time_in_force VARCHAR(10) DEFAULT 'GTC',  -- GTC, IOC, FOK
    reduce_only BOOLEAN DEFAULT false,
    post_only BOOLEAN DEFAULT false,
    client_order_id VARCHAR(100),
    error_message TEXT
);

CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_strategy ON orders(strategy_id);
CREATE INDEX idx_orders_symbol ON orders(symbol);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX idx_orders_exchange_order_id ON orders(exchange_order_id);
```

#### trades

```sql
CREATE TABLE trades (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    strategy_id UUID REFERENCES strategies(id),
    exchange_id INTEGER NOT NULL REFERENCES exchanges(id),

    -- Trade details
    symbol VARCHAR(20) NOT NULL,
    side VARCHAR(10) NOT NULL,  -- buy, sell

    -- Entry
    entry_order_id UUID REFERENCES orders(id),
    entry_price DECIMAL(20, 8) NOT NULL,
    entry_quantity DECIMAL(20, 8) NOT NULL,
    entry_time TIMESTAMP WITH TIME ZONE NOT NULL,
    entry_fee DECIMAL(20, 8) DEFAULT 0,

    -- Exit
    exit_order_id UUID REFERENCES orders(id),
    exit_price DECIMAL(20, 8),
    exit_quantity DECIMAL(20, 8),
    exit_time TIMESTAMP WITH TIME ZONE,
    exit_fee DECIMAL(20, 8) DEFAULT 0,
    exit_reason VARCHAR(50),  -- take_profit, stop_loss, signal, manual

    -- PnL
    gross_pnl DECIMAL(20, 8),
    net_pnl DECIMAL(20, 8),
    pnl_percentage DECIMAL(10, 4),

    -- Risk metrics
    risk_reward_ratio DECIMAL(10, 4),
    max_adverse_excursion DECIMAL(10, 4),  -- MAE
    max_favorable_excursion DECIMAL(10, 4),  -- MFE

    -- Trade duration
    duration_seconds INTEGER,

    -- Metadata
    notes TEXT,
    tags TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_trades_user ON trades(user_id);
CREATE INDEX idx_trades_strategy ON trades(strategy_id);
CREATE INDEX idx_trades_symbol ON trades(symbol);
CREATE INDEX idx_trades_entry_time ON trades(entry_time DESC);
CREATE INDEX idx_trades_exit_time ON trades(exit_time DESC);
```

#### positions

```sql
CREATE TABLE positions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    strategy_id UUID REFERENCES strategies(id),
    exchange_id INTEGER NOT NULL REFERENCES exchanges(id),

    symbol VARCHAR(20) NOT NULL,
    side VARCHAR(10) NOT NULL,  -- long, short

    -- Position details
    quantity DECIMAL(20, 8) NOT NULL,
    entry_price DECIMAL(20, 8) NOT NULL,
    current_price DECIMAL(20, 8),

    -- PnL
    unrealized_pnl DECIMAL(20, 8),
    unrealized_pnl_pct DECIMAL(10, 4),
    realized_pnl DECIMAL(20, 8) DEFAULT 0,

    -- Risk management
    stop_loss DECIMAL(20, 8),
    take_profit DECIMAL(20, 8),
    trailing_stop DECIMAL(10, 4),

    -- Metadata
    opened_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP WITH TIME ZONE,

    UNIQUE(user_id, strategy_id, exchange_id, symbol)
);

CREATE INDEX idx_positions_user ON positions(user_id);
CREATE INDEX idx_positions_strategy ON positions(strategy_id);
CREATE INDEX idx_positions_symbol ON positions(symbol);
CREATE INDEX idx_positions_open ON positions(closed_at) WHERE closed_at IS NULL;
```

#### backtests

```sql
CREATE TABLE backtests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    strategy_id UUID REFERENCES strategies(id),

    -- Backtest parameters
    name VARCHAR(100),
    symbols TEXT[] NOT NULL,
    timeframe VARCHAR(10) NOT NULL,
    start_date TIMESTAMP WITH TIME ZONE NOT NULL,
    end_date TIMESTAMP WITH TIME ZONE NOT NULL,
    initial_capital DECIMAL(20, 2) NOT NULL,

    -- Configuration
    strategy_config JSONB NOT NULL,
    commission_rate DECIMAL(6, 5) DEFAULT 0.001,
    slippage_rate DECIMAL(6, 5) DEFAULT 0.0005,

    -- Results
    status VARCHAR(20) DEFAULT 'pending',  -- pending, running, completed, failed
    total_trades INTEGER,
    winning_trades INTEGER,
    losing_trades INTEGER,
    win_rate DECIMAL(5, 4),

    -- Performance metrics
    total_return DECIMAL(10, 4),
    annual_return DECIMAL(10, 4),
    sharpe_ratio DECIMAL(10, 4),
    sortino_ratio DECIMAL(10, 4),
    max_drawdown DECIMAL(10, 4),
    max_drawdown_duration INTEGER,  -- in days

    -- Additional metrics
    profit_factor DECIMAL(10, 4),
    average_win DECIMAL(20, 8),
    average_loss DECIMAL(20, 8),
    largest_win DECIMAL(20, 8),
    largest_loss DECIMAL(20, 8),

    -- Results storage
    results_s3_key VARCHAR(255),  -- S3 key for detailed results
    equity_curve JSONB,  -- Simplified equity curve

    -- Execution
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_backtests_user ON backtests(user_id);
CREATE INDEX idx_backtests_strategy ON backtests(strategy_id);
CREATE INDEX idx_backtests_status ON backtests(status);
CREATE INDEX idx_backtests_created_at ON backtests(created_at DESC);
```

#### ml_models

```sql
CREATE TABLE ml_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),

    -- Model details
    name VARCHAR(100) NOT NULL,
    model_type VARCHAR(50) NOT NULL,  -- lstm, xgboost, transformer, dqn
    version VARCHAR(20) NOT NULL,
    description TEXT,

    -- Training details
    symbol VARCHAR(20),
    timeframe VARCHAR(10),
    features TEXT[],  -- List of feature names
    target VARCHAR(50),  -- price, direction, signal

    -- Hyperparameters
    hyperparameters JSONB,

    -- Training metrics
    train_loss DECIMAL(10, 6),
    val_loss DECIMAL(10, 6),
    test_loss DECIMAL(10, 6),
    accuracy DECIMAL(5, 4),

    -- Trading metrics (if backtested)
    backtest_sharpe DECIMAL(10, 4),
    backtest_returns DECIMAL(10, 4),

    -- Model storage
    model_s3_key VARCHAR(255),  -- S3 key for model file
    model_size_mb DECIMAL(10, 2),

    -- Status
    status VARCHAR(20) DEFAULT 'training',  -- training, trained, deployed, archived
    is_production BOOLEAN DEFAULT false,

    -- Metadata
    trained_at TIMESTAMP WITH TIME ZONE,
    deployed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ml_models_user ON ml_models(user_id);
CREATE INDEX idx_ml_models_type ON ml_models(model_type);
CREATE INDEX idx_ml_models_status ON ml_models(status);
CREATE INDEX idx_ml_models_production ON ml_models(is_production) WHERE is_production = true;
```

#### alerts

```sql
CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),

    -- Alert details
    type VARCHAR(50) NOT NULL,  -- price, indicator, trade, portfolio
    condition JSONB NOT NULL,  -- Alert condition
    message TEXT,

    -- Target
    symbol VARCHAR(20),
    strategy_id UUID REFERENCES strategies(id),

    -- Status
    is_active BOOLEAN DEFAULT true,
    is_triggered BOOLEAN DEFAULT false,
    triggered_at TIMESTAMP WITH TIME ZONE,
    trigger_count INTEGER DEFAULT 0,

    -- Notification
    notification_channels TEXT[],  -- email, sms, telegram, webhook

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_alerts_user ON alerts(user_id);
CREATE INDEX idx_alerts_active ON alerts(is_active) WHERE is_active = true;
```

---

## TimescaleDB Schema (Time-Series Data)

### OHLCV Candles

```sql
CREATE TABLE ohlcv (
    time TIMESTAMPTZ NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    exchange VARCHAR(50) NOT NULL,
    timeframe VARCHAR(10) NOT NULL,  -- 1m, 5m, 15m, 1h, 4h, 1d

    open DOUBLE PRECISION NOT NULL,
    high DOUBLE PRECISION NOT NULL,
    low DOUBLE PRECISION NOT NULL,
    close DOUBLE PRECISION NOT NULL,
    volume DOUBLE PRECISION NOT NULL,

    -- Additional metrics
    quote_volume DOUBLE PRECISION,
    trades_count INTEGER,
    taker_buy_volume DOUBLE PRECISION,

    PRIMARY KEY (time, symbol, exchange, timeframe)
);

-- Convert to hypertable (TimescaleDB)
SELECT create_hypertable('ohlcv', 'time',
    chunk_time_interval => INTERVAL '1 day');

-- Create indexes
CREATE INDEX idx_ohlcv_symbol_time ON ohlcv (symbol, time DESC);
CREATE INDEX idx_ohlcv_exchange_symbol ON ohlcv (exchange, symbol, time DESC);

-- Continuous aggregates for faster queries
CREATE MATERIALIZED VIEW ohlcv_1h
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 hour', time) AS hour,
    symbol,
    exchange,
    first(open, time) AS open,
    max(high) AS high,
    min(low) AS low,
    last(close, time) AS close,
    sum(volume) AS volume
FROM ohlcv
WHERE timeframe = '1m'
GROUP BY hour, symbol, exchange;

-- Retention policy (keep raw 1m data for 90 days)
SELECT add_retention_policy('ohlcv', INTERVAL '90 days');
```

### Tick Data

```sql
CREATE TABLE ticks (
    time TIMESTAMPTZ NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    exchange VARCHAR(50) NOT NULL,

    price DOUBLE PRECISION NOT NULL,
    quantity DOUBLE PRECISION NOT NULL,
    side VARCHAR(10),  -- buy, sell
    trade_id BIGINT,

    PRIMARY KEY (time, symbol, exchange, trade_id)
);

SELECT create_hypertable('ticks', 'time',
    chunk_time_interval => INTERVAL '1 hour');

CREATE INDEX idx_ticks_symbol_time ON ticks (symbol, time DESC);

-- Retention: keep tick data for 7 days
SELECT add_retention_policy('ticks', INTERVAL '7 days');
```

### Order Book Snapshots

```sql
CREATE TABLE orderbook_snapshots (
    time TIMESTAMPTZ NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    exchange VARCHAR(50) NOT NULL,

    bids JSONB NOT NULL,  -- [[price, quantity], ...]
    asks JSONB NOT NULL,  -- [[price, quantity], ...]

    bid_price_1 DOUBLE PRECISION,
    bid_volume_1 DOUBLE PRECISION,
    ask_price_1 DOUBLE PRECISION,
    ask_volume_1 DOUBLE PRECISION,

    spread DOUBLE PRECISION,
    mid_price DOUBLE PRECISION,

    PRIMARY KEY (time, symbol, exchange)
);

SELECT create_hypertable('orderbook_snapshots', 'time',
    chunk_time_interval => INTERVAL '1 hour');
```

### Performance Metrics

```sql
CREATE TABLE strategy_performance_metrics (
    time TIMESTAMPTZ NOT NULL,
    strategy_id UUID NOT NULL,

    -- Equity
    equity DECIMAL(20, 2),
    cash DECIMAL(20, 2),

    -- Returns
    daily_return DECIMAL(10, 6),
    cumulative_return DECIMAL(10, 6),

    -- Risk
    volatility DECIMAL(10, 6),
    sharpe_ratio DECIMAL(10, 4),
    max_drawdown DECIMAL(10, 4),

    -- Positions
    open_positions INTEGER,
    total_exposure DECIMAL(20, 2),

    PRIMARY KEY (time, strategy_id)
);

SELECT create_hypertable('strategy_performance_metrics', 'time');
```

---

## Redis Schema (Cache & Real-time)

### Key Patterns

```python
# User sessions
"session:{session_id}" → {user_id, expires_at, data}

# Real-time quotes
"quote:{exchange}:{symbol}" → {price, volume, timestamp}

# Order book
"orderbook:{exchange}:{symbol}:bids" → Sorted Set (price → quantity)
"orderbook:{exchange}:{symbol}:asks" → Sorted Set (price → quantity)

# Strategy state
"strategy:{strategy_id}:state" → {positions, signals, indicators}

# Rate limiting
"ratelimit:{user_id}:{endpoint}" → Counter with TTL

# Leaderboards
"leaderboard:daily" → Sorted Set (user_id → returns)
"leaderboard:monthly" → Sorted Set (user_id → returns)

# WebSocket connections
"ws:connections:{user_id}" → Set of connection IDs

# Model predictions cache
"ml:prediction:{model_id}:{symbol}:{timestamp}" → {prediction, confidence}
```

---

## MongoDB Schema (Document Storage)

### Strategy Configurations

```javascript
{
    _id: ObjectId("..."),
    strategy_id: "uuid",
    version: 1,
    config: {
        indicators: [
            {
                type: "SMA",
                period: 20,
                source: "close"
            },
            {
                type: "RSI",
                period: 14,
                overbought: 70,
                oversold: 30
            }
        ],
        entry_rules: [
            {
                condition: "AND",
                rules: [
                    "price > SMA_20",
                    "RSI < 30"
                ]
            }
        ],
        exit_rules: [
            {
                condition: "OR",
                rules: [
                    "price < SMA_20",
                    "RSI > 70"
                ]
            }
        ]
    },
    created_at: ISODate("2024-01-15T10:00:00Z")
}
```

### Application Logs

```javascript
{
    _id: ObjectId("..."),
    timestamp: ISODate("2024-01-15T10:00:00Z"),
    level: "ERROR",
    service: "execution-engine",
    message: "Order execution failed",
    context: {
        user_id: "uuid",
        strategy_id: "uuid",
        order_id: "uuid",
        symbol: "BTC/USDT",
        error: "Insufficient funds"
    },
    stack_trace: "..."
}
```

---

## Data Relationships

```
users (1) ────> (N) strategies
users (1) ────> (N) api_keys
users (1) ────> (N) user_exchange_credentials

strategies (1) ────> (N) orders
strategies (1) ────> (N) trades
strategies (1) ────> (N) positions
strategies (1) ────> (N) backtests

orders (1) ────> (1) trades (entry_order)
orders (1) ────> (1) trades (exit_order)

exchanges (1) ────> (N) user_exchange_credentials
exchanges (1) ────> (N) orders

ml_models (1) ────> (N) strategies (optional)
```

---

## Data Migration Strategy

### Alembic Migrations

```python
"""create_users_table

Revision ID: 001
Create Date: 2024-01-15 10:00:00

"""
from alembic import op
import sqlalchemy as sa

def upgrade():
    op.create_table(
        'users',
        sa.Column('id', sa.UUID(), primary_key=True),
        sa.Column('email', sa.String(255), unique=True, nullable=False),
        sa.Column('username', sa.String(50), unique=True, nullable=False),
        # ... other columns
    )

def downgrade():
    op.drop_table('users')
```

---

## Backup Strategy

### PostgreSQL
- **Frequency**: Daily full backup, hourly incremental
- **Retention**: 30 days
- **Method**: pg_dump + WAL archiving

### TimescaleDB
- **Frequency**: Daily snapshots
- **Retention**: 90 days for aggregates, 7 days for raw ticks
- **Method**: Continuous aggregates + compression

### Redis
- **Frequency**: RDB snapshots every 15 minutes
- **Method**: AOF (Append-Only File) + RDB

### MongoDB
- **Frequency**: Daily snapshots
- **Retention**: 30 days
- **Method**: mongodump

---

## Performance Optimization

### Indexing Strategy
- Index all foreign keys
- Composite indexes for common queries
- Partial indexes for filtered queries
- BRIN indexes for time-series data

### Partitioning
- Partition `trades` by month
- Partition `orders` by month
- Hypertable chunks for time-series data

### Connection Pooling
- pgBouncer for PostgreSQL (pool size: 100)
- Redis connection pool (pool size: 50)

---

## Summary

This database schema provides:

✅ **Comprehensive data model** for trading platform
✅ **Optimized for time-series** with TimescaleDB
✅ **Fast caching** with Redis
✅ **Flexible storage** with MongoDB
✅ **ACID transactions** for critical data
✅ **Scalable** with partitioning and sharding
✅ **Production-ready** with backup and monitoring

Inspired by best practices from Freqtrade, Hummingbot, Qlib, and financial industry standards.
