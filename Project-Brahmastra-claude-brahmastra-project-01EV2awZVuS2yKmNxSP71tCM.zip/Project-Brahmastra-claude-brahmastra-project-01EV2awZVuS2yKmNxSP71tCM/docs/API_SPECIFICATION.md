# Project Brahmastra - API Specification

**Version:** 1.0 (v1)
**Last Updated:** 2025-11-16
**Base URL**: `https://api.brahmastra.io/v1`

---

## Authentication

All API requests require authentication using JWT tokens or API keys.

### Get Access Token

```http
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "secure_password"
}
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

### Using the Token

```http
GET /strategies
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## API Endpoints

### 1. Authentication & Users

#### POST /auth/register
Register a new user

**Request:**
```json
{
  "email": "user@example.com",
  "username": "trader123",
  "password": "SecureP@ss123",
  "full_name": "John Doe"
}
```

**Response:** `201 Created`
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "email": "user@example.com",
  "username": "trader123",
  "created_at": "2024-01-15T10:00:00Z"
}
```

#### POST /auth/login
User login

#### POST /auth/refresh
Refresh access token

#### GET /auth/me
Get current user info

#### PUT /users/me
Update user profile

#### POST /users/me/api-keys
Generate API key

---

### 2. Strategies

#### GET /strategies
List all strategies

**Query Parameters:**
- `status` (optional): `draft`, `testing`, `live`, `paused`, `archived`
- `type` (optional): Strategy type filter
- `page` (default: 1): Page number
- `limit` (default: 20): Results per page

**Response:** `200 OK`
```json
{
  "data": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "MA Crossover BTC",
      "type": "ma_crossover",
      "status": "live",
      "symbols": ["BTC/USDT"],
      "timeframe": "1h",
      "total_trades": 150,
      "winning_trades": 95,
      "total_pnl": 1250.50,
      "sharpe_ratio": 1.85,
      "created_at": "2024-01-15T10:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 45,
    "pages": 3
  }
}
```

#### POST /strategies
Create a new strategy

**Request:**
```json
{
  "name": "RSI Oversold Strategy",
  "type": "rsi",
  "description": "Buy when RSI < 30, sell when RSI > 70",
  "config": {
    "rsi_period": 14,
    "rsi_oversold": 30,
    "rsi_overbought": 70,
    "stop_loss_pct": 0.02,
    "take_profit_pct": 0.05
  },
  "symbols": ["BTC/USDT", "ETH/USDT"],
  "timeframe": "15m",
  "max_position_size": 1000
}
```

**Response:** `201 Created`

#### GET /strategies/{id}
Get strategy details

#### PUT /strategies/{id}
Update strategy

#### DELETE /strategies/{id}
Delete strategy

#### POST /strategies/{id}/activate
Activate strategy for live trading

**Request:**
```json
{
  "exchange": "binance",
  "initial_capital": 10000,
  "risk_per_trade": 0.02
}
```

#### POST /strategies/{id}/deactivate
Deactivate strategy

#### GET /strategies/{id}/performance
Get strategy performance metrics

**Response:** `200 OK`
```json
{
  "strategy_id": "550e8400-e29b-41d4-a716-446655440000",
  "total_trades": 150,
  "winning_trades": 95,
  "losing_trades": 55,
  "win_rate": 0.6333,
  "total_pnl": 1250.50,
  "average_win": 25.30,
  "average_loss": -12.40,
  "profit_factor": 1.92,
  "sharpe_ratio": 1.85,
  "sortino_ratio": 2.15,
  "max_drawdown": -0.15,
  "equity_curve": [
    {"time": "2024-01-15T00:00:00Z", "equity": 10000},
    {"time": "2024-01-15T01:00:00Z", "equity": 10050},
    // ...
  ]
}
```

---

### 3. Backtesting

#### POST /backtests
Run a backtest

**Request:**
```json
{
  "strategy_id": "550e8400-e29b-41d4-a716-446655440000",
  "symbols": ["BTC/USDT"],
  "timeframe": "1h",
  "start_date": "2024-01-01T00:00:00Z",
  "end_date": "2024-03-01T00:00:00Z",
  "initial_capital": 10000,
  "commission_rate": 0.001,
  "slippage_rate": 0.0005
}
```

**Response:** `202 Accepted`
```json
{
  "backtest_id": "660e8400-e29b-41d4-a716-446655440000",
  "status": "pending",
  "estimated_duration_seconds": 120
}
```

#### GET /backtests/{id}
Get backtest results

**Response:** `200 OK`
```json
{
  "id": "660e8400-e29b-41d4-a716-446655440000",
  "status": "completed",
  "strategy_id": "550e8400-e29b-41d4-a716-446655440000",
  "start_date": "2024-01-01T00:00:00Z",
  "end_date": "2024-03-01T00:00:00Z",
  "initial_capital": 10000,
  "final_equity": 11250.50,
  "total_return": 0.1250,
  "annual_return": 0.5123,
  "sharpe_ratio": 1.85,
  "sortino_ratio": 2.15,
  "max_drawdown": -0.15,
  "max_drawdown_duration": 7,
  "total_trades": 85,
  "winning_trades": 55,
  "losing_trades": 30,
  "win_rate": 0.647,
  "average_win": 45.20,
  "average_loss": -22.10,
  "profit_factor": 2.05,
  "largest_win": 125.50,
  "largest_loss": -75.30,
  "completed_at": "2024-01-15T10:05:00Z",
  "duration_seconds": 115
}
```

#### GET /backtests
List all backtests

#### DELETE /backtests/{id}
Delete backtest

#### GET /backtests/{id}/trades
Get backtest trade history

#### GET /backtests/{id}/equity-curve
Get backtest equity curve

#### POST /backtests/{id}/optimize
Optimize strategy parameters

**Request:**
```json
{
  "parameters": {
    "rsi_period": {"min": 10, "max": 20, "step": 1},
    "rsi_oversold": {"min": 20, "max": 40, "step": 5},
    "rsi_overbought": {"min": 60, "max": 80, "step": 5}
  },
  "optimization_metric": "sharpe_ratio",
  "max_trials": 100
}
```

---

### 4. Trading

#### GET /orders
List orders

**Query Parameters:**
- `symbol` (optional): Filter by symbol
- `status` (optional): Filter by status
- `strategy_id` (optional): Filter by strategy
- `start_date` (optional): From date
- `end_date` (optional): To date

**Response:** `200 OK`
```json
{
  "data": [
    {
      "id": "770e8400-e29b-41d4-a716-446655440000",
      "exchange_order_id": "12345678",
      "symbol": "BTC/USDT",
      "side": "buy",
      "type": "limit",
      "status": "filled",
      "quantity": 0.1,
      "price": 45000,
      "filled_quantity": 0.1,
      "average_fill_price": 44995,
      "fee": 4.50,
      "created_at": "2024-01-15T10:00:00Z",
      "filled_at": "2024-01-15T10:00:15Z"
    }
  ]
}
```

#### POST /orders
Place a new order

**Request:**
```json
{
  "symbol": "BTC/USDT",
  "side": "buy",
  "type": "limit",
  "quantity": 0.1,
  "price": 45000,
  "time_in_force": "GTC",
  "strategy_id": "550e8400-e29b-41d4-a716-446655440000",
  "exchange": "binance"
}
```

**Response:** `201 Created`

#### GET /orders/{id}
Get order details

#### DELETE /orders/{id}
Cancel an order

#### GET /trades
List trades

#### GET /trades/{id}
Get trade details

---

### 5. Portfolio

#### GET /portfolio
Get portfolio overview

**Response:** `200 OK`
```json
{
  "total_equity": 12500.50,
  "cash": 5000.00,
  "positions_value": 7500.50,
  "unrealized_pnl": 250.50,
  "realized_pnl": 1250.00,
  "total_pnl": 1500.50,
  "daily_return": 0.025,
  "total_return": 0.125,
  "positions": [
    {
      "symbol": "BTC/USDT",
      "quantity": 0.15,
      "entry_price": 45000,
      "current_price": 46500,
      "unrealized_pnl": 225.00,
      "unrealized_pnl_pct": 0.0333,
      "side": "long"
    }
  ]
}
```

#### GET /portfolio/positions
Get open positions

#### GET /portfolio/history
Get portfolio history

**Query Parameters:**
- `start_date`: From date
- `end_date`: To date
- `timeframe`: `1h`, `1d`, `1w`, `1M`

**Response:** `200 OK`
```json
{
  "data": [
    {
      "time": "2024-01-15T00:00:00Z",
      "equity": 10000,
      "cash": 8000,
      "positions_value": 2000,
      "daily_return": 0
    },
    {
      "time": "2024-01-16T00:00:00Z",
      "equity": 10250,
      "cash": 8000,
      "positions_value": 2250,
      "daily_return": 0.025
    }
  ]
}
```

---

### 6. Market Data

#### GET /market-data/ohlcv
Get OHLCV candle data

**Query Parameters:**
- `symbol` (required): Trading pair
- `exchange` (required): Exchange name
- `timeframe` (required): `1m`, `5m`, `15m`, `1h`, `4h`, `1d`
- `start_date` (required): From date
- `end_date` (required): To date
- `limit` (optional, max 1000): Number of candles

**Response:** `200 OK`
```json
{
  "symbol": "BTC/USDT",
  "exchange": "binance",
  "timeframe": "1h",
  "data": [
    {
      "time": "2024-01-15T10:00:00Z",
      "open": 45000,
      "high": 45500,
      "low": 44800,
      "close": 45200,
      "volume": 125.5
    }
  ]
}
```

#### GET /market-data/ticker
Get current ticker price

**Query Parameters:**
- `symbol` (required)
- `exchange` (required)

**Response:** `200 OK`
```json
{
  "symbol": "BTC/USDT",
  "price": 45200,
  "bid": 45195,
  "ask": 45205,
  "volume_24h": 12500,
  "change_24h": 0.025,
  "timestamp": "2024-01-15T10:00:00Z"
}
```

#### GET /market-data/orderbook
Get order book

**Query Parameters:**
- `symbol` (required)
- `exchange` (required)
- `depth` (default: 20)

**Response:** `200 OK`
```json
{
  "symbol": "BTC/USDT",
  "bids": [
    [45195, 1.5],
    [45190, 2.3]
  ],
  "asks": [
    [45205, 1.2],
    [45210, 3.1]
  ],
  "timestamp": "2024-01-15T10:00:00Z"
}
```

---

### 7. ML Models

#### GET /ml/models
List ML models

#### POST /ml/models/train
Train a new model

**Request:**
```json
{
  "name": "BTC Price Predictor v1",
  "model_type": "lstm",
  "symbol": "BTC/USDT",
  "timeframe": "1h",
  "features": ["price", "volume", "rsi", "macd"],
  "target": "price",
  "hyperparameters": {
    "lstm_units": 128,
    "dropout": 0.2,
    "epochs": 100,
    "batch_size": 32
  },
  "train_start_date": "2023-01-01",
  "train_end_date": "2024-01-01"
}
```

**Response:** `202 Accepted`
```json
{
  "model_id": "880e8400-e29b-41d4-a716-446655440000",
  "status": "training",
  "estimated_duration_minutes": 15
}
```

#### GET /ml/models/{id}
Get model details

#### POST /ml/models/{id}/predict
Make predictions

**Request:**
```json
{
  "data": [
    {
      "price": 45000,
      "volume": 125.5,
      "rsi": 55,
      "macd": 120
    }
  ]
}
```

**Response:** `200 OK`
```json
{
  "predictions": [45250],
  "confidence": [0.85],
  "model_id": "880e8400-e29b-41d4-a716-446655440000"
}
```

#### POST /ml/models/{id}/deploy
Deploy model to production

#### DELETE /ml/models/{id}
Delete model

---

### 8. Alerts

#### GET /alerts
List alerts

#### POST /alerts
Create alert

**Request:**
```json
{
  "type": "price",
  "symbol": "BTC/USDT",
  "condition": {
    "operator": "greater_than",
    "value": 50000
  },
  "message": "BTC crossed $50k!",
  "notification_channels": ["email", "telegram"]
}
```

#### PUT /alerts/{id}
Update alert

#### DELETE /alerts/{id}
Delete alert

---

## WebSocket API

**URL:** `wss://api.brahmastra.io/v1/ws`

### Authentication

```json
{
  "type": "auth",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### Subscribe to Channels

```json
{
  "type": "subscribe",
  "channels": [
    "prices.BTC/USDT",
    "orders.user.123",
    "portfolio.user.123"
  ]
}
```

### Real-time Price Updates

```json
{
  "type": "price",
  "channel": "prices.BTC/USDT",
  "data": {
    "symbol": "BTC/USDT",
    "price": 45200,
    "volume": 125.5,
    "timestamp": "2024-01-15T10:00:00Z"
  }
}
```

### Order Updates

```json
{
  "type": "order",
  "channel": "orders.user.123",
  "data": {
    "id": "770e8400-e29b-41d4-a716-446655440000",
    "status": "filled",
    "filled_quantity": 0.1,
    "average_fill_price": 45000
  }
}
```

---

## Error Responses

### Error Format

```json
{
  "error": {
    "code": "INVALID_PARAMETER",
    "message": "The 'symbol' parameter is required",
    "details": {
      "parameter": "symbol"
    }
  }
}
```

### Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `UNAUTHORIZED` | 401 | Invalid or missing authentication |
| `FORBIDDEN` | 403 | Insufficient permissions |
| `NOT_FOUND` | 404 | Resource not found |
| `INVALID_PARAMETER` | 400 | Invalid request parameter |
| `VALIDATION_ERROR` | 422 | Request validation failed |
| `RATE_LIMIT_EXCEEDED` | 429 | Too many requests |
| `INTERNAL_ERROR` | 500 | Server error |
| `EXCHANGE_ERROR` | 502 | Exchange API error |

---

## Rate Limiting

| Tier | Requests per Minute | WebSocket Connections |
|------|---------------------|----------------------|
| **Free** | 60 | 1 |
| **Premium** | 600 | 10 |
| **Enterprise** | 6000 | 100 |

**Headers:**
```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1705315200
```

---

## Pagination

Paginated endpoints use cursor-based pagination:

**Request:**
```http
GET /strategies?page=2&limit=20
```

**Response:**
```json
{
  "data": [...],
  "pagination": {
    "page": 2,
    "limit": 20,
    "total": 150,
    "pages": 8,
    "has_next": true,
    "has_prev": true
  }
}
```

---

## Webhooks

Users can configure webhooks for events:

### Webhook Events

- `trade.created`
- `trade.closed`
- `order.filled`
- `order.cancelled`
- `alert.triggered`
- `strategy.activated`
- `strategy.deactivated`

### Webhook Payload

```json
{
  "event": "trade.created",
  "timestamp": "2024-01-15T10:00:00Z",
  "data": {
    "trade_id": "990e8400-e29b-41d4-a716-446655440000",
    "symbol": "BTC/USDT",
    "side": "buy",
    "quantity": 0.1,
    "price": 45000
  }
}
```

---

## SDK Examples

### Python

```python
from brahmastra import BrahmastraClient

client = BrahmastraClient(api_key="your_api_key")

# Get strategies
strategies = client.strategies.list(status="live")

# Create backtest
backtest = client.backtests.create(
    strategy_id="550e8400-e29b-41d4-a716-446655440000",
    symbols=["BTC/USDT"],
    start_date="2024-01-01",
    end_date="2024-03-01"
)

# Place order
order = client.orders.create(
    symbol="BTC/USDT",
    side="buy",
    type="market",
    quantity=0.1
)
```

### JavaScript

```javascript
import { BrahmastraClient } from '@brahmastra/sdk';

const client = new BrahmastraClient({ apiKey: 'your_api_key' });

// Subscribe to price updates
client.ws.subscribe('prices.BTC/USDT', (data) => {
  console.log('Price update:', data.price);
});

// Create strategy
const strategy = await client.strategies.create({
  name: 'MA Crossover',
  type: 'ma_crossover',
  config: { /* ... */ }
});
```

---

## Summary

This API provides:

✅ **RESTful API** for all CRUD operations
✅ **WebSocket API** for real-time updates
✅ **Comprehensive endpoints** for trading, backtesting, ML
✅ **Rate limiting** and authentication
✅ **Webhooks** for event notifications
✅ **SDKs** for popular languages

Following REST best practices and inspired by leading trading platforms.
