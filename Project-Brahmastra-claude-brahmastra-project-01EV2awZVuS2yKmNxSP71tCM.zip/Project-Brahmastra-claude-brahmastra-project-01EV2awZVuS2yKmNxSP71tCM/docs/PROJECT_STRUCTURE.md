# Project Brahmastra - Detailed Project Structure

**Version:** 1.0
**Last Updated:** 2025-11-16

---

## Complete Directory Structure

```
project-brahmastra/
│
├── .github/                           # GitHub configuration
│   ├── workflows/                     # CI/CD pipelines
│   │   ├── test.yml                  # Run tests
│   │   ├── build.yml                 # Build Docker images
│   │   ├── deploy.yml                # Deploy to environments
│   │   ├── security-scan.yml         # Security scanning
│   │   └── docs.yml                  # Build and deploy docs
│   ├── ISSUE_TEMPLATE/               # Issue templates
│   ├── PULL_REQUEST_TEMPLATE.md      # PR template
│   └── CODE_OF_CONDUCT.md            # Community guidelines
│
├── docs/                              # Documentation
│   ├── MASTER_PROJECT_PLAN.md        # Project master plan
│   ├── ARCHITECTURE.md               # System architecture
│   ├── TECHNOLOGY_STACK.md           # Tech stack details
│   ├── API_SPECIFICATION.md          # API documentation
│   ├── DATABASE_SCHEMA.md            # Database design
│   ├── ML_AI_STRATEGY.md             # ML/AI implementation
│   ├── DEPLOYMENT_STRATEGY.md        # Deployment guide
│   ├── DEVELOPMENT_ROADMAP.md        # Development timeline
│   ├── CONTRIBUTING.md               # Contribution guidelines
│   ├── USER_GUIDE.md                 # User documentation
│   └── images/                       # Documentation images
│
├── backend/                           # Backend application
│   ├── app/                          # Main application
│   │   ├── __init__.py
│   │   ├── main.py                   # FastAPI application entry
│   │   ├── config.py                 # Configuration management
│   │   ├── dependencies.py           # Dependency injection
│   │   │
│   │   ├── api/                      # API layer
│   │   │   ├── __init__.py
│   │   │   ├── v1/                   # API version 1
│   │   │   │   ├── __init__.py
│   │   │   │   ├── endpoints/
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   ├── auth.py       # Authentication endpoints
│   │   │   │   │   ├── strategies.py # Strategy management
│   │   │   │   │   ├── backtests.py  # Backtesting endpoints
│   │   │   │   │   ├── trades.py     # Trade management
│   │   │   │   │   ├── portfolio.py  # Portfolio endpoints
│   │   │   │   │   ├── market_data.py# Market data endpoints
│   │   │   │   │   ├── ml_models.py  # ML model management
│   │   │   │   │   ├── users.py      # User management
│   │   │   │   │   └── webhooks.py   # Webhook handlers
│   │   │   │   └── router.py         # API router
│   │   │   └── websocket/
│   │   │       ├── __init__.py
│   │   │       ├── connection_manager.py
│   │   │       ├── handlers/
│   │   │       │   ├── price_updates.py
│   │   │       │   ├── order_updates.py
│   │   │       │   └── portfolio_updates.py
│   │   │       └── events.py
│   │   │
│   │   ├── core/                     # Core business logic
│   │   │   ├── __init__.py
│   │   │   │
│   │   │   ├── strategy/             # Strategy engine
│   │   │   │   ├── __init__.py
│   │   │   │   ├── base_strategy.py  # Abstract base strategy
│   │   │   │   ├── strategy_loader.py
│   │   │   │   ├── strategy_executor.py
│   │   │   │   ├── signal_generator.py
│   │   │   │   ├── strategy_registry.py
│   │   │   │   ├── strategy_validator.py
│   │   │   │   └── built_in/         # Built-in strategies
│   │   │   │       ├── __init__.py
│   │   │   │       ├── ma_crossover.py
│   │   │   │       ├── rsi_strategy.py
│   │   │   │       ├── bollinger_bands.py
│   │   │   │       ├── mean_reversion.py
│   │   │   │       └── ml_strategy.py
│   │   │   │
│   │   │   ├── execution/            # Execution engine
│   │   │   │   ├── __init__.py
│   │   │   │   ├── order_router.py   # Smart order routing
│   │   │   │   ├── order_executor.py
│   │   │   │   ├── fill_tracker.py
│   │   │   │   ├── order_manager.py
│   │   │   │   ├── execution_algos.py # TWAP, VWAP, etc.
│   │   │   │   └── slippage_optimizer.py
│   │   │   │
│   │   │   ├── risk/                 # Risk management
│   │   │   │   ├── __init__.py
│   │   │   │   ├── position_sizer.py
│   │   │   │   ├── risk_calculator.py
│   │   │   │   ├── stop_loss_manager.py
│   │   │   │   ├── exposure_manager.py
│   │   │   │   ├── drawdown_protector.py
│   │   │   │   └── risk_limits.py
│   │   │   │
│   │   │   ├── portfolio/            # Portfolio management
│   │   │   │   ├── __init__.py
│   │   │   │   ├── portfolio_manager.py
│   │   │   │   ├── position_tracker.py
│   │   │   │   ├── pnl_calculator.py
│   │   │   │   ├── rebalancer.py
│   │   │   │   └── portfolio_optimizer.py
│   │   │   │
│   │   │   └── backtesting/          # Backtesting engine
│   │   │       ├── __init__.py
│   │   │       ├── backtest_engine.py
│   │   │       ├── event_processor.py
│   │   │       ├── vectorized_engine.py
│   │   │       ├── time_machine.py
│   │   │       ├── broker/
│   │   │       │   ├── virtual_broker.py
│   │   │       │   ├── order_simulator.py
│   │   │       │   ├── slippage_model.py
│   │   │       │   └── commission_model.py
│   │   │       ├── analysis/
│   │   │       │   ├── performance_analyzer.py
│   │   │       │   ├── sharpe_calculator.py
│   │   │       │   ├── drawdown_analyzer.py
│   │   │       │   └── trade_analyzer.py
│   │   │       ├── optimization/
│   │   │       │   ├── parameter_optimizer.py
│   │   │       │   ├── walk_forward.py
│   │   │       │   ├── genetic_optimizer.py
│   │   │       │   └── grid_search.py
│   │   │       └── reporting/
│   │   │           ├── report_generator.py
│   │   │           ├── equity_curve.py
│   │   │           ├── tearsheet.py
│   │   │           └── html_reporter.py
│   │   │
│   │   ├── data/                     # Data layer
│   │   │   ├── __init__.py
│   │   │   │
│   │   │   ├── market_data/          # Market data management
│   │   │   │   ├── __init__.py
│   │   │   │   ├── data_manager.py
│   │   │   │   ├── data_fetcher.py
│   │   │   │   ├── data_normalizer.py
│   │   │   │   ├── data_validator.py
│   │   │   │   ├── bar_aggregator.py
│   │   │   │   └── orderbook_manager.py
│   │   │   │
│   │   │   ├── historical/           # Historical data
│   │   │   │   ├── __init__.py
│   │   │   │   ├── historical_loader.py
│   │   │   │   ├── data_cache.py
│   │   │   │   ├── data_downloader.py
│   │   │   │   └── data_cleaner.py
│   │   │   │
│   │   │   ├── realtime/             # Real-time data
│   │   │   │   ├── __init__.py
│   │   │   │   ├── websocket_manager.py
│   │   │   │   ├── stream_processor.py
│   │   │   │   ├── tick_processor.py
│   │   │   │   └── live_feed.py
│   │   │   │
│   │   │   └── alternative/          # Alternative data
│   │   │       ├── __init__.py
│   │   │       ├── news_fetcher.py
│   │   │       ├── sentiment_analyzer.py
│   │   │       └── social_media_tracker.py
│   │   │
│   │   ├── ml/                       # ML/AI layer
│   │   │   ├── __init__.py
│   │   │   │
│   │   │   ├── models/               # ML models
│   │   │   │   ├── __init__.py
│   │   │   │   ├── base_model.py
│   │   │   │   ├── lstm_model.py
│   │   │   │   ├── transformer_model.py
│   │   │   │   ├── ensemble_model.py
│   │   │   │   ├── xgboost_model.py
│   │   │   │   └── reinforcement/
│   │   │   │       ├── __init__.py
│   │   │   │       ├── dqn_agent.py
│   │   │   │       ├── ppo_agent.py
│   │   │   │       └── a3c_agent.py
│   │   │   │
│   │   │   ├── features/             # Feature engineering
│   │   │   │   ├── __init__.py
│   │   │   │   ├── feature_engineer.py
│   │   │   │   ├── technical_features.py
│   │   │   │   ├── fundamental_features.py
│   │   │   │   ├── sentiment_features.py
│   │   │   │   └── feature_selector.py
│   │   │   │
│   │   │   ├── training/             # Model training
│   │   │   │   ├── __init__.py
│   │   │   │   ├── trainer.py
│   │   │   │   ├── cross_validator.py
│   │   │   │   ├── hyperparameter_tuner.py
│   │   │   │   └── early_stopper.py
│   │   │   │
│   │   │   ├── inference/            # Model inference
│   │   │   │   ├── __init__.py
│   │   │   │   ├── predictor.py
│   │   │   │   ├── batch_predictor.py
│   │   │   │   ├── online_predictor.py
│   │   │   │   └── model_cache.py
│   │   │   │
│   │   │   └── monitoring/           # Model monitoring
│   │   │       ├── __init__.py
│   │   │       ├── model_monitor.py
│   │   │       ├── drift_detector.py
│   │   │       └── performance_tracker.py
│   │   │
│   │   ├── exchanges/                # Exchange connectivity
│   │   │   ├── __init__.py
│   │   │   │
│   │   │   ├── base/                 # Base classes
│   │   │   │   ├── __init__.py
│   │   │   │   ├── base_exchange.py
│   │   │   │   ├── base_connector.py
│   │   │   │   └── exchange_types.py
│   │   │   │
│   │   │   ├── connectors/           # Exchange connectors
│   │   │   │   ├── __init__.py
│   │   │   │   ├── binance_connector.py
│   │   │   │   ├── coinbase_connector.py
│   │   │   │   ├── alpaca_connector.py
│   │   │   │   ├── kraken_connector.py
│   │   │   │   ├── ftx_connector.py
│   │   │   │   ├── bybit_connector.py
│   │   │   │   ├── kucoin_connector.py
│   │   │   │   ├── gate_io_connector.py
│   │   │   │   ├── huobi_connector.py
│   │   │   │   └── okx_connector.py
│   │   │   │
│   │   │   ├── utils/                # Exchange utilities
│   │   │   │   ├── __init__.py
│   │   │   │   ├── rate_limiter.py
│   │   │   │   ├── connection_pool.py
│   │   │   │   ├── retry_handler.py
│   │   │   │   └── error_mapper.py
│   │   │   │
│   │   │   └── websocket/            # WebSocket handling
│   │   │       ├── __init__.py
│   │   │       ├── ws_manager.py
│   │   │       ├── ws_handler.py
│   │   │       └── reconnection.py
│   │   │
│   │   ├── models/                   # Database models
│   │   │   ├── __init__.py
│   │   │   ├── user.py
│   │   │   ├── strategy.py
│   │   │   ├── trade.py
│   │   │   ├── order.py
│   │   │   ├── portfolio.py
│   │   │   ├── backtest.py
│   │   │   ├── ml_model.py
│   │   │   └── alert.py
│   │   │
│   │   ├── schemas/                  # Pydantic schemas
│   │   │   ├── __init__.py
│   │   │   ├── user.py
│   │   │   ├── strategy.py
│   │   │   ├── trade.py
│   │   │   ├── order.py
│   │   │   ├── portfolio.py
│   │   │   ├── backtest.py
│   │   │   ├── ml_model.py
│   │   │   └── common.py
│   │   │
│   │   ├── services/                 # Business services
│   │   │   ├── __init__.py
│   │   │   ├── auth_service.py
│   │   │   ├── strategy_service.py
│   │   │   ├── trade_service.py
│   │   │   ├── portfolio_service.py
│   │   │   ├── backtest_service.py
│   │   │   ├── ml_service.py
│   │   │   └── notification_service.py
│   │   │
│   │   ├── indicators/               # Technical indicators
│   │   │   ├── __init__.py
│   │   │   ├── trend/
│   │   │   │   ├── sma.py
│   │   │   │   ├── ema.py
│   │   │   │   ├── macd.py
│   │   │   │   └── adx.py
│   │   │   ├── momentum/
│   │   │   │   ├── rsi.py
│   │   │   │   ├── stochastic.py
│   │   │   │   └── cci.py
│   │   │   ├── volatility/
│   │   │   │   ├── bollinger_bands.py
│   │   │   │   ├── atr.py
│   │   │   │   └── keltner.py
│   │   │   └── volume/
│   │   │       ├── obv.py
│   │   │       ├── vwap.py
│   │   │       └── mfi.py
│   │   │
│   │   ├── utils/                    # Utilities
│   │   │   ├── __init__.py
│   │   │   ├── logger.py             # Logging utilities
│   │   │   ├── crypto.py             # Encryption
│   │   │   ├── validators.py         # Input validation
│   │   │   ├── helpers.py            # Helper functions
│   │   │   ├── decorators.py         # Custom decorators
│   │   │   └── constants.py          # Constants
│   │   │
│   │   └── middleware/               # Middleware
│   │       ├── __init__.py
│   │       ├── auth_middleware.py
│   │       ├── cors_middleware.py
│   │       ├── rate_limit_middleware.py
│   │       ├── logging_middleware.py
│   │       └── error_handler.py
│   │
│   ├── tests/                        # Tests
│   │   ├── __init__.py
│   │   ├── conftest.py               # Pytest configuration
│   │   │
│   │   ├── unit/                     # Unit tests
│   │   │   ├── test_strategies.py
│   │   │   ├── test_indicators.py
│   │   │   ├── test_risk.py
│   │   │   ├── test_models.py
│   │   │   └── test_utils.py
│   │   │
│   │   ├── integration/              # Integration tests
│   │   │   ├── test_api.py
│   │   │   ├── test_exchanges.py
│   │   │   ├── test_database.py
│   │   │   └── test_backtesting.py
│   │   │
│   │   ├── e2e/                      # End-to-end tests
│   │   │   ├── test_trading_flow.py
│   │   │   ├── test_backtest_flow.py
│   │   │   └── test_ml_flow.py
│   │   │
│   │   └── performance/              # Performance tests
│   │       ├── test_backtest_speed.py
│   │       └── test_api_load.py
│   │
│   ├── alembic/                      # Database migrations
│   │   ├── versions/
│   │   ├── env.py
│   │   └── alembic.ini
│   │
│   ├── scripts/                      # Utility scripts
│   │   ├── init_db.py               # Initialize database
│   │   ├── seed_data.py             # Seed test data
│   │   ├── download_data.py         # Download historical data
│   │   └── train_models.py          # Train ML models
│   │
│   ├── requirements.txt              # Python dependencies
│   ├── pyproject.toml               # Poetry configuration
│   ├── Dockerfile                   # Docker image
│   ├── .env.example                 # Environment variables example
│   └── README.md                    # Backend README
│
├── frontend/                         # Frontend application
│   ├── public/                       # Static files
│   │   ├── index.html
│   │   ├── favicon.ico
│   │   └── manifest.json
│   │
│   ├── src/                          # Source code
│   │   ├── index.tsx                 # Entry point
│   │   ├── App.tsx                   # Root component
│   │   │
│   │   ├── components/               # Reusable components
│   │   │   ├── common/
│   │   │   │   ├── Button.tsx
│   │   │   │   ├── Input.tsx
│   │   │   │   ├── Modal.tsx
│   │   │   │   └── Spinner.tsx
│   │   │   ├── charts/
│   │   │   │   ├── CandlestickChart.tsx
│   │   │   │   ├── EquityCurve.tsx
│   │   │   │   └── PerformanceChart.tsx
│   │   │   ├── strategy/
│   │   │   │   ├── StrategyCard.tsx
│   │   │   │   ├── StrategyForm.tsx
│   │   │   │   └── StrategyList.tsx
│   │   │   └── portfolio/
│   │   │       ├── PortfolioOverview.tsx
│   │   │       ├── PositionTable.tsx
│   │   │       └── PnLDisplay.tsx
│   │   │
│   │   ├── pages/                    # Page components
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Strategies.tsx
│   │   │   ├── Backtesting.tsx
│   │   │   ├── LiveTrading.tsx
│   │   │   ├── Portfolio.tsx
│   │   │   ├── Analytics.tsx
│   │   │   ├── MLModels.tsx
│   │   │   └── Settings.tsx
│   │   │
│   │   ├── hooks/                    # Custom hooks
│   │   │   ├── useAuth.ts
│   │   │   ├── useWebSocket.ts
│   │   │   ├── useStrategies.ts
│   │   │   └── useMarketData.ts
│   │   │
│   │   ├── store/                    # State management
│   │   │   ├── index.ts
│   │   │   ├── slices/
│   │   │   │   ├── authSlice.ts
│   │   │   │   ├── strategySlice.ts
│   │   │   │   ├── portfolioSlice.ts
│   │   │   │   └── marketDataSlice.ts
│   │   │   └── middleware.ts
│   │   │
│   │   ├── services/                 # API services
│   │   │   ├── api.ts                # Axios instance
│   │   │   ├── authService.ts
│   │   │   ├── strategyService.ts
│   │   │   ├── backtestService.ts
│   │   │   └── websocketService.ts
│   │   │
│   │   ├── types/                    # TypeScript types
│   │   │   ├── strategy.ts
│   │   │   ├── trade.ts
│   │   │   ├── portfolio.ts
│   │   │   └── marketData.ts
│   │   │
│   │   ├── utils/                    # Utilities
│   │   │   ├── formatters.ts
│   │   │   ├── validators.ts
│   │   │   └── helpers.ts
│   │   │
│   │   └── styles/                   # Global styles
│   │       ├── global.css
│   │       └── theme.ts
│   │
│   ├── package.json                  # NPM dependencies
│   ├── tsconfig.json                 # TypeScript config
│   ├── Dockerfile                    # Docker image
│   └── README.md                     # Frontend README
│
├── ml-service/                       # ML microservice (optional)
│   ├── app/
│   │   ├── main.py
│   │   ├── models/
│   │   ├── training/
│   │   └── inference/
│   ├── Dockerfile
│   └── requirements.txt
│
├── data-pipeline/                    # Data pipeline service
│   ├── airflow/                      # Apache Airflow
│   │   ├── dags/
│   │   │   ├── download_daily_data.py
│   │   │   ├── train_models.py
│   │   │   └── cleanup_old_data.py
│   │   └── config/
│   └── scripts/
│
├── infrastructure/                   # Infrastructure as code
│   ├── terraform/                    # Terraform configs
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   ├── modules/
│   │   │   ├── kubernetes/
│   │   │   ├── database/
│   │   │   └── networking/
│   │   └── environments/
│   │       ├── dev/
│   │       ├── staging/
│   │       └── prod/
│   │
│   ├── kubernetes/                   # Kubernetes manifests
│   │   ├── base/
│   │   │   ├── deployment.yaml
│   │   │   ├── service.yaml
│   │   │   ├── ingress.yaml
│   │   │   └── configmap.yaml
│   │   ├── overlays/
│   │   │   ├── dev/
│   │   │   ├── staging/
│   │   │   └── prod/
│   │   └── helm/
│   │       └── brahmastra/
│   │           ├── Chart.yaml
│   │           ├── values.yaml
│   │           └── templates/
│   │
│   └── docker/                       # Docker files
│       ├── docker-compose.yml
│       ├── docker-compose.dev.yml
│       └── docker-compose.prod.yml
│
├── monitoring/                       # Monitoring configs
│   ├── prometheus/
│   │   ├── prometheus.yml
│   │   └── alerts.yml
│   ├── grafana/
│   │   ├── dashboards/
│   │   │   ├── trading_dashboard.json
│   │   │   ├── system_dashboard.json
│   │   │   └── ml_dashboard.json
│   │   └── datasources/
│   └── elk/
│       ├── elasticsearch.yml
│       ├── logstash.conf
│       └── kibana.yml
│
├── notebooks/                        # Jupyter notebooks
│   ├── research/
│   │   ├── strategy_research.ipynb
│   │   ├── feature_engineering.ipynb
│   │   └── model_experiments.ipynb
│   ├── analysis/
│   │   ├── backtest_analysis.ipynb
│   │   └── performance_analysis.ipynb
│   └── data_exploration/
│       └── market_data_eda.ipynb
│
├── strategies/                       # User-defined strategies
│   ├── examples/
│   │   ├── simple_ma_cross.py
│   │   ├── rsi_oversold.py
│   │   └── ml_prediction.py
│   └── custom/
│       └── user_strategies/
│
├── data/                            # Data storage (local dev)
│   ├── historical/                  # Historical market data
│   ├── models/                      # Trained ML models
│   ├── backtests/                   # Backtest results
│   └── logs/                        # Application logs
│
├── scripts/                         # Project-level scripts
│   ├── setup.sh                    # Setup development environment
│   ├── test.sh                     # Run all tests
│   ├── build.sh                    # Build all services
│   ├── deploy.sh                   # Deploy to environments
│   └── cleanup.sh                  # Cleanup resources
│
├── .gitignore                      # Git ignore file
├── .env.example                    # Environment variables template
├── .pre-commit-config.yaml         # Pre-commit hooks
├── docker-compose.yml              # Docker Compose config
├── Makefile                        # Make commands
├── README.md                       # Project README
├── LICENSE                         # License file
└── CHANGELOG.md                    # Change log

```

---

## Key Directories Explained

### `/backend/app/`
The heart of the application. Contains all business logic, API endpoints, ML models, and integrations.

### `/backend/app/core/`
Core trading functionality:
- **strategy/**: Strategy execution engine
- **execution/**: Order execution and routing
- **risk/**: Risk management system
- **portfolio/**: Portfolio tracking and optimization
- **backtesting/**: Backtesting engine and analysis

### `/backend/app/ml/`
ML/AI components:
- **models/**: Model implementations (LSTM, Transformers, RL agents)
- **features/**: Feature engineering pipeline
- **training/**: Model training infrastructure
- **inference/**: Prediction and inference services
- **monitoring/**: Model performance tracking

### `/backend/app/exchanges/`
Exchange connectivity layer with unified interface for all supported exchanges.

### `/frontend/src/`
React-based frontend application with modern UI/UX.

### `/infrastructure/`
Infrastructure as Code (IaC) for provisioning cloud resources and Kubernetes deployments.

### `/monitoring/`
Observability stack configurations (Prometheus, Grafana, ELK).

### `/notebooks/`
Jupyter notebooks for research, experimentation, and analysis.

---

## File Naming Conventions

### Python Files
- **Modules**: `lowercase_with_underscores.py`
- **Classes**: `PascalCase` (inside files)
- **Functions**: `lowercase_with_underscores()`
- **Constants**: `UPPERCASE_WITH_UNDERSCORES`

### TypeScript Files
- **Components**: `PascalCase.tsx`
- **Utilities**: `camelCase.ts`
- **Types**: `PascalCase.ts`
- **Hooks**: `useCamelCase.ts`

### Configuration Files
- **Docker**: `Dockerfile`, `docker-compose.yml`
- **Kubernetes**: `resource-name.yaml`
- **Terraform**: `main.tf`, `variables.tf`

---

## Module Organization Principles

### 1. Single Responsibility
Each module has one clear purpose.

### 2. Dependency Injection
Dependencies passed as parameters, not hardcoded.

### 3. Interface Segregation
Small, focused interfaces instead of large monolithic ones.

### 4. DRY (Don't Repeat Yourself)
Common functionality extracted to utilities.

### 5. Testability
All modules designed for easy testing.

---

## Import Structure

### Backend (Python)

```python
# Standard library imports
import os
import sys
from datetime import datetime

# Third-party imports
import pandas as pd
import numpy as np
from fastapi import FastAPI

# Local imports
from app.core.strategy import BaseStrategy
from app.utils.logger import get_logger
from app.models.trade import Trade
```

### Frontend (TypeScript)

```typescript
// External libraries
import React from 'react';
import { useDispatch } from 'react-redux';

// Internal components
import { Button } from '@/components/common';
import { useAuth } from '@/hooks/useAuth';

// Types
import type { Strategy } from '@/types/strategy';

// Styles
import styles from './Component.module.css';
```

---

## Configuration Management

### Environment-Specific Configs

```
config/
├── default.yaml          # Default configuration
├── development.yaml      # Development overrides
├── staging.yaml          # Staging overrides
└── production.yaml       # Production overrides
```

### Secrets Management

```python
# Use environment variables for secrets
ALPACA_API_KEY = os.getenv("ALPACA_API_KEY")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET")

# Or use secrets manager
from app.utils.secrets import get_secret
api_key = get_secret("alpaca_api_key")
```

---

## Data Storage Organization

### Local Development

```
data/
├── historical/
│   ├── crypto/
│   │   ├── binance/
│   │   │   └── BTCUSDT_1m_2024.parquet
│   │   └── coinbase/
│   └── stocks/
│       └── alpaca/
├── models/
│   ├── lstm_btc_v1.h5
│   └── xgboost_eth_v2.pkl
└── backtests/
    └── backtest_2024_01_15_ma_cross.json
```

### Production (Cloud Storage)

```
s3://brahmastra-data/
├── historical/{exchange}/{symbol}/{year}/{month}/
├── models/{model_type}/{version}/
└── backtests/{user_id}/{backtest_id}/
```

---

## Logging Structure

### Log Files

```
logs/
├── app/
│   ├── app.log                    # Application logs
│   ├── app.2024-01-15.log        # Rotated logs
│   └── errors.log                 # Error-only logs
├── trading/
│   ├── trades.log                 # Trade execution logs
│   └── orders.log                 # Order logs
├── ml/
│   ├── training.log               # Model training logs
│   └── predictions.log            # Prediction logs
└── audit/
    └── audit.log                  # Audit trail
```

---

## Testing Organization

### Test Structure Mirrors Source

```
backend/
├── app/
│   └── core/
│       └── strategy/
│           └── base_strategy.py
└── tests/
    └── unit/
        └── core/
            └── strategy/
                └── test_base_strategy.py
```

---

## Documentation Structure

### Code Documentation

```python
def calculate_position_size(
    account_balance: float,
    risk_per_trade: float,
    entry_price: float,
    stop_loss_price: float
) -> float:
    """
    Calculate position size based on risk parameters.

    Args:
        account_balance: Total account balance in USD
        risk_per_trade: Risk percentage (0.01 = 1%)
        entry_price: Entry price for the trade
        stop_loss_price: Stop loss price

    Returns:
        Position size in base currency units

    Example:
        >>> calculate_position_size(10000, 0.02, 100, 95)
        40.0
    """
    risk_amount = account_balance * risk_per_trade
    risk_per_unit = abs(entry_price - stop_loss_price)
    return risk_amount / risk_per_unit
```

---

## Summary

This project structure provides:

✅ **Clear separation of concerns**
✅ **Scalable and maintainable codebase**
✅ **Easy navigation and discovery**
✅ **Support for multiple deployment environments**
✅ **Comprehensive testing infrastructure**
✅ **Professional development workflows**
✅ **Production-ready organization**

The structure incorporates best practices from all 10 studied repositories while maintaining flexibility for future growth.
