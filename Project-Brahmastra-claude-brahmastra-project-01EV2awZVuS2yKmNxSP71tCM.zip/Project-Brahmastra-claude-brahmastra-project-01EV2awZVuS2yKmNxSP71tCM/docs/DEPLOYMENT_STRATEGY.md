# Project Brahmastra - Deployment Strategy

**Version:** 1.0
**Last Updated:** 2025-11-16

---

## Deployment Environments

### 1. Development (dev)
- **Purpose**: Active development and testing
- **Infrastructure**: Local Docker Compose or lightweight cloud
- **Access**: Development team only
- **Data**: Mock/sample data
- **Updates**: Continuous (every commit to `dev` branch)

### 2. Staging (staging)
- **Purpose**: Pre-production testing and QA
- **Infrastructure**: Cloud environment mirroring production
- **Access**: Dev team + QA + stakeholders
- **Data**: Anonymized production data
- **Updates**: Weekly or on-demand

### 3. Production (prod)
- **Purpose**: Live platform for end users
- **Infrastructure**: Fully redundant cloud deployment
- **Access**: Public (authenticated users)
- **Data**: Live production data
- **Updates**: Bi-weekly or monthly releases

---

## Cloud Infrastructure

### Cloud Provider Strategy: Multi-Cloud Ready

We design for cloud-agnostic deployment with primary support for:

1. **AWS** (Primary recommendation)
2. **GCP** (Alternative)
3. **Azure** (Alternative)

### AWS Architecture

```
┌────────────────────────────────────────────────────────────┐
│                    CloudFront CDN                           │
│                  (Global Edge Locations)                    │
└──────────────────────┬─────────────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────────────┐
│                  Route 53 (DNS)                            │
└──────────────────────┬─────────────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────────────┐
│          Application Load Balancer (ALB)                   │
│                 (Multi-AZ)                                 │
└─────────┬────────────┬────────────┬─────────────────────────┘
          │            │            │
    ┌─────▼────┐  ┌───▼─────┐ ┌───▼──────┐
    │  EKS     │  │  EKS    │ │   EKS    │
    │ Cluster  │  │ Cluster │ │ Cluster  │
    │  AZ-1    │  │  AZ-2   │ │  AZ-3    │
    └─────┬────┘  └───┬─────┘ └───┬──────┘
          │           │           │
    ┌─────▼───────────▼───────────▼──────┐
    │         Service Mesh (Istio)       │
    └─────┬───────────┬───────────┬──────┘
          │           │           │
    ┌─────▼──┐   ┌───▼────┐  ┌──▼──────┐
    │  RDS   │   │ Redis  │  │ S3      │
    │Postgres│   │ElastiC.│  │Storage  │
    │(Multi  │   │(Cluster│  │         │
    │  AZ)   │   │)       │  │         │
    └────────┘   └────────┘  └─────────┘
```

### AWS Services Map

| Component | AWS Service | Purpose |
|-----------|-------------|---------|
| **Compute** | EKS (Kubernetes) | Container orchestration |
| **Database** | RDS PostgreSQL | Primary relational database |
| **Time-Series** | RDS PostgreSQL + TimescaleDB | Market data storage |
| **Cache** | ElastiCache Redis | Caching and pub/sub |
| **Object Storage** | S3 | Backtest results, models, logs |
| **CDN** | CloudFront | Static asset delivery |
| **DNS** | Route 53 | Domain management |
| **Load Balancer** | ALB | Traffic distribution |
| **Secrets** | Secrets Manager | API keys, credentials |
| **Monitoring** | CloudWatch | Logs and metrics |
| **Container Registry** | ECR | Docker images |
| **Message Queue** | SQS + SNS | Async messaging |
| **Functions** | Lambda | Serverless functions |

---

## Kubernetes Architecture

### Cluster Setup

```yaml
# Cluster Specification
apiVersion: v1
kind: ClusterConfig
metadata:
  name: brahmastra-prod
  region: us-east-1

nodeGroups:
  - name: general-purpose
    instanceType: t3.large
    desiredCapacity: 3
    minSize: 3
    maxSize: 10
    labels:
      role: general

  - name: ml-training
    instanceType: p3.2xlarge  # GPU instances
    desiredCapacity: 1
    minSize: 0
    maxSize: 5
    labels:
      role: ml-training
    taints:
      - key: nvidia.com/gpu
        value: "true"
        effect: NoSchedule

  - name: high-memory
    instanceType: r5.xlarge
    desiredCapacity: 2
    minSize: 1
    maxSize: 5
    labels:
      role: high-memory
```

### Namespace Organization

```yaml
namespaces:
  - production      # Production workloads
  - staging         # Staging environment
  - monitoring      # Prometheus, Grafana
  - ingress        # Nginx Ingress Controller
  - cert-manager   # SSL certificate management
  - istio-system   # Service mesh
```

### Deployment Example: API Service

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-server
  namespace: production
  labels:
    app: api-server
    version: v1
spec:
  replicas: 3
  selector:
    matchLabels:
      app: api-server
  template:
    metadata:
      labels:
        app: api-server
        version: v1
    spec:
      containers:
      - name: api
        image: brahmastra/api:v1.0.0
        ports:
        - containerPort: 8000
          name: http
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: database-credentials
              key: url
        - name: REDIS_URL
          valueFrom:
            configMapKeyRef:
              name: redis-config
              key: url
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "1Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: api-server
  namespace: production
spec:
  selector:
    app: api-server
  ports:
  - port: 80
    targetPort: 8000
  type: LoadBalancer
```

### Horizontal Pod Autoscaler

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: api-server-hpa
  namespace: production
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: api-server
  minReplicas: 3
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

---

## Docker Images

### Multi-Stage Dockerfile (Backend)

```dockerfile
# Stage 1: Builder
FROM python:3.11-slim as builder

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

# Stage 2: Runtime
FROM python:3.11-slim

WORKDIR /app

# Copy dependencies from builder
COPY --from=builder /root/.local /root/.local

# Copy application code
COPY ./app ./app

# Create non-root user
RUN useradd -m -u 1000 appuser && chown -R appuser:appuser /app
USER appuser

# Add local bin to PATH
ENV PATH=/root/.local/bin:$PATH

# Expose port
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s \
  CMD python -c "import requests; requests.get('http://localhost:8000/health')"

# Run application
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Frontend Dockerfile

```dockerfile
# Stage 1: Build
FROM node:20-alpine as build

WORKDIR /app

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

# Stage 2: Serve
FROM nginx:alpine

COPY --from=build /app/build /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
```

### Image Tagging Strategy

```bash
# Development
brahmastra/api:dev-abc123

# Staging
brahmastra/api:staging-1.0.0-rc1

# Production
brahmastra/api:1.0.0
brahmastra/api:1.0
brahmastra/api:1
brahmastra/api:latest
```

---

## CI/CD Pipeline

### GitHub Actions Workflow

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop, staging]
  pull_request:
    branches: [main]

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'

      - name: Install dependencies
        run: |
          pip install -r requirements.txt
          pip install pytest pytest-cov

      - name: Run tests
        run: |
          pytest --cov=app --cov-report=xml

      - name: Upload coverage
        uses: codecov/codecov-action@v3

  build:
    needs: test
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write

    steps:
      - uses: actions/checkout@v3

      - name: Log in to Container Registry
        uses: docker/login-action@v2
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Extract metadata
        id: meta
        uses: docker/metadata-action@v4
        with:
          images: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}
          tags: |
            type=ref,event=branch
            type=ref,event=pr
            type=semver,pattern={{version}}
            type=semver,pattern={{major}}.{{minor}}

      - name: Build and push
        uses: docker/build-push-action@v4
        with:
          context: ./backend
          push: true
          tags: ${{ steps.meta.outputs.tags }}
          labels: ${{ steps.meta.outputs.labels }}

  deploy-staging:
    needs: build
    if: github.ref == 'refs/heads/staging'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v2
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: us-east-1

      - name: Update kubeconfig
        run: |
          aws eks update-kubeconfig --name brahmastra-staging

      - name: Deploy to staging
        run: |
          kubectl set image deployment/api-server \
            api=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:staging \
            -n staging
          kubectl rollout status deployment/api-server -n staging

  deploy-production:
    needs: build
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production
    steps:
      - uses: actions/checkout@v3

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v2
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: us-east-1

      - name: Update kubeconfig
        run: |
          aws eks update-kubeconfig --name brahmastra-prod

      - name: Deploy to production
        run: |
          kubectl set image deployment/api-server \
            api=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:latest \
            -n production
          kubectl rollout status deployment/api-server -n production

      - name: Slack notification
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          text: 'Production deployment completed!'
          webhook_url: ${{ secrets.SLACK_WEBHOOK }}
```

---

## Database Deployment

### PostgreSQL (RDS)

```hcl
# Terraform configuration
resource "aws_db_instance" "postgres" {
  identifier = "brahmastra-prod-db"

  # Instance
  engine               = "postgres"
  engine_version       = "15.4"
  instance_class       = "db.r5.xlarge"

  # Storage
  allocated_storage     = 100
  max_allocated_storage = 1000
  storage_type          = "gp3"
  storage_encrypted     = true

  # Database
  db_name  = "brahmastra"
  username = "admin"
  password = var.db_password

  # High Availability
  multi_az               = true
  backup_retention_period = 30
  backup_window          = "03:00-04:00"
  maintenance_window     = "Mon:04:00-Mon:05:00"

  # Monitoring
  enabled_cloudwatch_logs_exports = ["postgresql"]
  performance_insights_enabled    = true

  # Network
  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.database.id]

  # Deletion protection
  deletion_protection = true
  skip_final_snapshot = false
  final_snapshot_identifier = "brahmastra-prod-final-snapshot"

  tags = {
    Name        = "brahmastra-prod-db"
    Environment = "production"
  }
}
```

### Redis (ElastiCache)

```hcl
resource "aws_elasticache_replication_group" "redis" {
  replication_group_id       = "brahmastra-prod-redis"
  replication_group_description = "Redis cluster for Brahmastra"

  engine               = "redis"
  engine_version       = "7.0"
  node_type            = "cache.r5.large"
  number_cache_clusters = 3

  # High Availability
  automatic_failover_enabled = true
  multi_az_enabled          = true

  # Subnet and Security
  subnet_group_name  = aws_elasticache_subnet_group.main.name
  security_group_ids = [aws_security_group.redis.id]

  # Maintenance
  maintenance_window = "sun:05:00-sun:06:00"
  snapshot_window    = "03:00-04:00"
  snapshot_retention_limit = 7

  # Encryption
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true

  tags = {
    Name        = "brahmastra-prod-redis"
    Environment = "production"
  }
}
```

---

## Monitoring & Observability

### Prometheus Configuration

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'kubernetes-apiservers'
    kubernetes_sd_configs:
    - role: endpoints
    scheme: https
    tls_config:
      ca_file: /var/run/secrets/kubernetes.io/serviceaccount/ca.crt
    bearer_token_file: /var/run/secrets/kubernetes.io/serviceaccount/token

  - job_name: 'kubernetes-pods'
    kubernetes_sd_configs:
    - role: pod
    relabel_configs:
    - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
      action: keep
      regex: true
    - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_path]
      action: replace
      target_label: __metrics_path__
      regex: (.+)

  - job_name: 'api-server'
    static_configs:
    - targets: ['api-server:8000']

  - job_name: 'database'
    static_configs:
    - targets: ['postgres-exporter:9187']

  - job_name: 'redis'
    static_configs:
    - targets: ['redis-exporter:9121']
```

### Grafana Dashboards

Dashboards for:
1. **System Overview**: CPU, memory, network
2. **Trading Metrics**: Orders, trades, PnL
3. **API Performance**: Latency, throughput, errors
4. **Database Performance**: Query time, connections
5. **ML Models**: Prediction accuracy, drift
6. **Business Metrics**: Users, strategies, volume

---

## Backup & Disaster Recovery

### Backup Strategy

```yaml
Backup Schedule:
  Database (PostgreSQL):
    Full: Daily at 3 AM UTC
    Incremental: Every 6 hours
    Retention: 30 days

  Redis:
    RDB Snapshot: Every 15 minutes
    AOF: Continuous
    Retention: 7 days

  Object Storage (S3):
    Versioning: Enabled
    Lifecycle: 90 days → Glacier
    Cross-region replication: Enabled

  Kubernetes:
    Velero backup: Daily
    Retention: 30 days
```

### Disaster Recovery

```yaml
Recovery Time Objective (RTO): 1 hour
Recovery Point Objective (RPO): 15 minutes

Disaster Recovery Plan:
  1. Automated failover to standby region
  2. Restore from latest backup
  3. Validate data integrity
  4. Switch DNS to DR region
  5. Monitor and verify

DR Drills: Quarterly
```

---

## Security Measures

### Network Security

```yaml
Security Layers:
  - WAF (Web Application Firewall)
  - DDoS protection (CloudFlare)
  - VPC with private subnets
  - Security groups (least privilege)
  - Network ACLs
  - VPN for admin access

SSL/TLS:
  - Let's Encrypt certificates
  - TLS 1.3 minimum
  - HSTS enabled
  - Certificate auto-renewal
```

### Application Security

```yaml
Security Measures:
  - JWT authentication
  - API key rotation every 90 days
  - Rate limiting per user/IP
  - Input validation
  - SQL injection prevention
  - XSS protection
  - CSRF tokens
  - Secrets in Vault/Secrets Manager
  - No hardcoded credentials
  - Regular security audits
```

---

## Scaling Strategy

### Vertical Scaling
- Database: Increase instance size (up to 32 cores, 256GB RAM)
- Redis: Upgrade node type
- Application: Increase pod resources

### Horizontal Scaling
- Application: HPA (3-100 pods)
- Database: Read replicas (up to 5)
- Redis: Cluster mode (up to 500 nodes)

### Auto-Scaling Triggers

```yaml
Triggers:
  - CPU > 70%
  - Memory > 80%
  - Request queue > 100
  - Response time > 500ms
```

---

## Cost Optimization

### Strategies

1. **Right-sizing**: Regular resource audits
2. **Spot Instances**: For ML training (up to 70% savings)
3. **Reserved Instances**: For stable workloads (up to 50% savings)
4. **S3 Lifecycle**: Move old data to Glacier
5. **Database optimization**: Proper indexing, query optimization
6. **CDN**: Reduce origin traffic
7. **Compression**: Enable gzip/brotli

### Estimated Monthly Costs (Production)

```
Compute (EKS): $1,500
Database (RDS): $800
Cache (Redis): $400
Storage (S3): $200
CDN (CloudFront): $300
Data Transfer: $400
Monitoring: $100
Other Services: $300

Total: ~$4,000/month
```

---

## Deployment Checklist

### Pre-Deployment
- [ ] All tests passing
- [ ] Security scan completed
- [ ] Database migrations tested
- [ ] Backup verified
- [ ] Rollback plan prepared
- [ ] Stakeholders notified

### Deployment
- [ ] Deploy to staging
- [ ] Run smoke tests
- [ ] Deploy to production (off-peak hours)
- [ ] Monitor metrics
- [ ] Verify functionality

### Post-Deployment
- [ ] Monitor for errors
- [ ] Check performance metrics
- [ ] User feedback
- [ ] Document issues
- [ ] Retrospective

---

## Conclusion

This deployment strategy provides:

✅ **High Availability**: Multi-AZ, auto-scaling
✅ **Disaster Recovery**: Automated backups, DR plan
✅ **Security**: Multiple layers, regular audits
✅ **Scalability**: Horizontal and vertical scaling
✅ **Monitoring**: Comprehensive observability
✅ **Cost-Effective**: Optimization strategies
✅ **Production-Ready**: Battle-tested architecture

Ready for enterprise-grade deployment! 🚀
