"""
Project Brahmastra - AI-Powered Autonomous Trading Platform
Backend Application Package
"""

__version__ = "1.0.0"
__author__ = "Project Brahmastra Team"
