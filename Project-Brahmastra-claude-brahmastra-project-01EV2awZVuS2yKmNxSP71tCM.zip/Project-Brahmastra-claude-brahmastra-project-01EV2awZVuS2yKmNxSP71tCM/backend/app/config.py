"""
Configuration Management
Centralized configuration for the entire application
"""

import os
from typing import Optional, Dict, Any
from pydantic_settings import BaseSettings
from pydantic import Field
import json
from pathlib import Path


class Settings(BaseSettings):
    """Application Settings"""

    # Application
    APP_NAME: str = "Project Brahmastra"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = Field(default=False, env="DEBUG")
    ENVIRONMENT: str = Field(default="development", env="ENVIRONMENT")

    # API
    API_V1_PREFIX: str = "/api/v1"
    SECRET_KEY: str = Field(default="your-secret-key-change-this", env="SECRET_KEY")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days

    # Database
    DATABASE_URL: str = Field(
        default="postgresql://brahmastra:password@localhost:5432/brahmastra",
        env="DATABASE_URL"
    )

    # Redis
    REDIS_URL: str = Field(
        default="redis://localhost:6379/0",
        env="REDIS_URL"
    )

    # TimescaleDB (uses same connection as PostgreSQL)
    TIMESCALE_URL: str = Field(
        default="postgresql://brahmastra:password@localhost:5432/brahmastra_timeseries",
        env="TIMESCALE_URL"
    )

    # Exchange API Keys (loaded from config.json)
    BINANCE_API_KEY: Optional[str] = Field(default=None, env="BINANCE_API_KEY")
    BINANCE_API_SECRET: Optional[str] = Field(default=None, env="BINANCE_API_SECRET")
    COINBASE_API_KEY: Optional[str] = Field(default=None, env="COINBASE_API_KEY")
    COINBASE_API_SECRET: Optional[str] = Field(default=None, env="COINBASE_API_SECRET")
    ALPACA_API_KEY: Optional[str] = Field(default=None, env="ALPACA_API_KEY")
    ALPACA_API_SECRET: Optional[str] = Field(default=None, env="ALPACA_API_SECRET")

    # Risk Management
    DEFAULT_RISK_PER_TRADE: float = 0.02  # 2%
    MAX_POSITION_SIZE: float = 10000.0
    MAX_OPEN_POSITIONS: int = 5

    # ML/AI
    MODEL_PATH: str = "models/"
    ENABLE_ML: bool = True

    # Data
    DATA_PATH: str = "data/"
    CACHE_TTL: int = 300  # 5 minutes

    # Logging
    LOG_LEVEL: str = Field(default="INFO", env="LOG_LEVEL")
    LOG_FILE: str = "logs/brahmastra.log"

    class Config:
        env_file = ".env"
        case_sensitive = True


def load_exchange_credentials(config_path: str = "config.json") -> Dict[str, Any]:
    """
    Load exchange credentials from config.json

    Args:
        config_path: Path to config file

    Returns:
        Dictionary with exchange credentials
    """
    config_file = Path(config_path)

    if not config_file.exists():
        # Try parent directory
        config_file = Path("..") / config_path

    if not config_file.exists():
        print(f"Warning: Config file not found at {config_path}")
        return {}

    try:
        with open(config_file, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading config: {e}")
        return {}


# Global settings instance
settings = Settings()

# Load exchange credentials
exchange_config = load_exchange_credentials()

# Update settings with loaded credentials
if exchange_config:
    settings.BINANCE_API_KEY = exchange_config.get("binance_api_key", settings.BINANCE_API_KEY)
    settings.BINANCE_API_SECRET = exchange_config.get("binance_api_secret", settings.BINANCE_API_SECRET)
    settings.COINBASE_API_KEY = exchange_config.get("coinbase_api_key", settings.COINBASE_API_KEY)
    settings.COINBASE_API_SECRET = exchange_config.get("coinbase_api_secret", settings.COINBASE_API_SECRET)
    settings.ALPACA_API_KEY = exchange_config.get("alpaca_api_key", settings.ALPACA_API_KEY)
    settings.ALPACA_API_SECRET = exchange_config.get("alpaca_api_secret", settings.ALPACA_API_SECRET)
    settings.DEFAULT_RISK_PER_TRADE = exchange_config.get("risk_per_trade", settings.DEFAULT_RISK_PER_TRADE)


def get_settings() -> Settings:
    """Get application settings"""
    return settings
