"""
Volatility Indicators
"""

import pandas as pd
import numpy as np
from typing import Union
from app.indicators.trend import sma


def bollinger_bands(
    data: Union[pd.Series, np.ndarray],
    period: int = 20,
    std_dev: float = 2.0
) -> tuple:
    """
    Bollinger Bands

    Args:
        data: Price data
        period: Period for moving average
        std_dev: Number of standard deviations

    Returns:
        (upper_band, middle_band, lower_band)
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)

    middle_band = sma(data, period)
    std = data.rolling(window=period).std()

    upper_band = middle_band + (std_dev * std)
    lower_band = middle_band - (std_dev * std)

    return upper_band, middle_band, lower_band


def atr(
    high: Union[pd.Series, np.ndarray],
    low: Union[pd.Series, np.ndarray],
    close: Union[pd.Series, np.ndarray],
    period: int = 14
) -> pd.Series:
    """
    Average True Range

    Args:
        high: High prices
        low: Low prices
        close: Close prices
        period: Period for ATR

    Returns:
        ATR values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)

    # Calculate True Range
    tr1 = high - low
    tr2 = abs(high - close.shift())
    tr3 = abs(low - close.shift())

    true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    # Calculate ATR
    atr_values = true_range.rolling(window=period).mean()

    return atr_values
