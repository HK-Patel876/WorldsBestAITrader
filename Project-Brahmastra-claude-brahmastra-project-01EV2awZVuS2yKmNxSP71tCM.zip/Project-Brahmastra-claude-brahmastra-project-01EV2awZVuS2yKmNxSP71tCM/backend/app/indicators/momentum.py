"""
Momentum Indicators
"""

import pandas as pd
import numpy as np
from typing import Union


def rsi(data: Union[pd.Series, np.ndarray], period: int = 14) -> pd.Series:
    """
    Relative Strength Index

    Args:
        data: Price data
        period: Period for RSI

    Returns:
        RSI values (0-100)
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)

    # Calculate price changes
    delta = data.diff()

    # Separate gains and losses
    gains = delta.where(delta > 0, 0)
    losses = -delta.where(delta < 0, 0)

    # Calculate average gains and losses
    avg_gains = gains.rolling(window=period).mean()
    avg_losses = losses.rolling(window=period).mean()

    # Calculate RS and RSI
    rs = avg_gains / avg_losses
    rsi_values = 100 - (100 / (1 + rs))

    return rsi_values


def stochastic(
    high: Union[pd.Series, np.ndarray],
    low: Union[pd.Series, np.ndarray],
    close: Union[pd.Series, np.ndarray],
    k_period: int = 14,
    d_period: int = 3
) -> tuple:
    """
    Stochastic Oscillator

    Args:
        high: High prices
        low: Low prices
        close: Close prices
        k_period: %K period
        d_period: %D period

    Returns:
        (%K, %D)
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)

    # Calculate %K
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()

    k = 100 * (close - lowest_low) / (highest_high - lowest_low)

    # Calculate %D (SMA of %K)
    d = k.rolling(window=d_period).mean()

    return k, d
