"""
Trend Indicators
"""

import pandas as pd
import numpy as np
from typing import Union


def sma(data: Union[pd.Series, np.ndarray], period: int = 20) -> pd.Series:
    """
    Simple Moving Average

    Args:
        data: Price data
        period: Period for SMA

    Returns:
        SMA values
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)

    return data.rolling(window=period).mean()


def ema(data: Union[pd.Series, np.ndarray], period: int = 20) -> pd.Series:
    """
    Exponential Moving Average

    Args:
        data: Price data
        period: Period for EMA

    Returns:
        EMA values
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)

    return data.ewm(span=period, adjust=False).mean()


def macd(
    data: Union[pd.Series, np.ndarray],
    fast_period: int = 12,
    slow_period: int = 26,
    signal_period: int = 9
) -> tuple:
    """
    MACD (Moving Average Convergence Divergence)

    Args:
        data: Price data
        fast_period: Fast EMA period
        slow_period: Slow EMA period
        signal_period: Signal line period

    Returns:
        (macd_line, signal_line, histogram)
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)

    fast_ema = ema(data, fast_period)
    slow_ema = ema(data, slow_period)

    macd_line = fast_ema - slow_ema
    signal_line = ema(macd_line, signal_period)
    histogram = macd_line - signal_line

    return macd_line, signal_line, histogram
