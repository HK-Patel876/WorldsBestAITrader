"""
Backtesting Engine
Event-driven backtesting for strategies
Inspired by Backtrader, VectorBT, and Zipline
"""

import pandas as pd
from typing import Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime
from app.core.strategy.base_strategy import BaseStrategy


@dataclass
class BacktestResult:
    """Backtest results"""
    initial_capital: float
    final_equity: float
    total_return: float
    trades: List[Dict] = field(default_factory=list)
    equity_curve: List[Dict] = field(default_factory=list)

    # Performance metrics
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: float = 0.0
    profit_factor: float = 0.0
    sharpe_ratio: float = 0.0
    max_drawdown: float = 0.0
    average_win: float = 0.0
    average_loss: float = 0.0


class BacktestEngine:
    """
    Simple but effective backtesting engine

    Features:
    - Event-driven execution
    - Realistic fill simulation
    - Commission and slippage modeling
    - Performance analytics
    """

    def __init__(
        self,
        strategy: BaseStrategy,
        initial_capital: float = 10000.0,
        commission: float = 0.001,  # 0.1%
        slippage: float = 0.0005    # 0.05%
    ):
        """
        Initialize backtester

        Args:
            strategy: Trading strategy
            initial_capital: Starting capital
            commission: Commission rate
            slippage: Slippage rate
        """
        self.strategy = strategy
        self.initial_capital = initial_capital
        self.commission = commission
        self.slippage = slippage

        # State
        self.cash = initial_capital
        self.position = 0.0
        self.position_price = 0.0
        self.trades: List[Dict] = []
        self.equity_curve: List[Dict] = []

    def run(self, dataframe: pd.DataFrame) -> BacktestResult:
        """
        Run backtest

        Args:
            dataframe: OHLCV data

        Returns:
            Backtest results
        """
        # Analyze with strategy
        df = self.strategy.analyze(dataframe.copy())

        # Simulate trading
        for i in range(len(df)):
            row = df.iloc[i]

            # Check for entry signal
            if row.get("enter_long", False) and self.position == 0:
                self._enter_long(row)

            # Check for exit signal
            elif row.get("exit_long", False) and self.position > 0:
                self._exit_long(row)

            # Record equity
            current_equity = self._calculate_equity(row["close"])
            self.equity_curve.append({
                "time": row.get("time", i),
                "equity": current_equity,
                "cash": self.cash,
                "position_value": self.position * row["close"]
            })

        # Close any open position at end
        if self.position > 0:
            last_row = df.iloc[-1]
            self._exit_long(last_row)

        # Calculate performance metrics
        return self._calculate_results()

    def _enter_long(self, row: pd.Series):
        """Enter long position"""
        price = row["close"] * (1 + self.slippage)  # Simulate slippage
        quantity = (self.cash * 0.95) / price  # Use 95% of cash

        cost = quantity * price
        commission_cost = cost * self.commission

        if cost + commission_cost <= self.cash:
            self.position = quantity
            self.position_price = price
            self.cash -= (cost + commission_cost)

            self.trades.append({
                "type": "entry",
                "time": row.get("time"),
                "price": price,
                "quantity": quantity,
                "cost": cost + commission_cost
            })

    def _exit_long(self, row: pd.Series):
        """Exit long position"""
        if self.position == 0:
            return

        price = row["close"] * (1 - self.slippage)  # Simulate slippage
        proceeds = self.position * price
        commission_cost = proceeds * self.commission

        pnl = proceeds - (self.position * self.position_price)
        pnl_pct = (price / self.position_price) - 1

        self.cash += (proceeds - commission_cost)

        self.trades.append({
            "type": "exit",
            "time": row.get("time"),
            "price": price,
            "quantity": self.position,
            "proceeds": proceeds - commission_cost,
            "pnl": pnl,
            "pnl_pct": pnl_pct
        })

        self.position = 0.0
        self.position_price = 0.0

    def _calculate_equity(self, current_price: float) -> float:
        """Calculate current equity"""
        position_value = self.position * current_price if self.position > 0 else 0
        return self.cash + position_value

    def _calculate_results(self) -> BacktestResult:
        """Calculate backtest results"""
        final_equity = self.cash + (self.position * self.equity_curve[-1]["equity"] if self.position > 0 else 0)
        total_return = (final_equity / self.initial_capital) - 1

        # Analyze trades
        exit_trades = [t for t in self.trades if t["type"] == "exit"]
        winning_trades = [t for t in exit_trades if t["pnl"] > 0]
        losing_trades = [t for t in exit_trades if t["pnl"] <= 0]

        total_trades = len(exit_trades)
        num_winning = len(winning_trades)
        num_losing = len(losing_trades)

        win_rate = num_winning / total_trades if total_trades > 0 else 0

        total_wins = sum(t["pnl"] for t in winning_trades)
        total_losses = abs(sum(t["pnl"] for t in losing_trades))

        profit_factor = total_wins / total_losses if total_losses > 0 else 0
        average_win = total_wins / num_winning if num_winning > 0 else 0
        average_loss = total_losses / num_losing if num_losing > 0 else 0

        # Calculate max drawdown
        equity_series = pd.Series([e["equity"] for e in self.equity_curve])
        running_max = equity_series.expanding().max()
        drawdown = (equity_series - running_max) / running_max
        max_drawdown = drawdown.min()

        # Calculate Sharpe ratio (simplified)
        returns = equity_series.pct_change().dropna()
        sharpe_ratio = (returns.mean() / returns.std()) * (252 ** 0.5) if len(returns) > 0 else 0

        return BacktestResult(
            initial_capital=self.initial_capital,
            final_equity=final_equity,
            total_return=total_return,
            trades=exit_trades,
            equity_curve=self.equity_curve,
            total_trades=total_trades,
            winning_trades=num_winning,
            losing_trades=num_losing,
            win_rate=win_rate,
            profit_factor=profit_factor,
            sharpe_ratio=sharpe_ratio,
            max_drawdown=max_drawdown,
            average_win=average_win,
            average_loss=average_loss
        )
