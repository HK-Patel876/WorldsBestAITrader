"""
Moving Average Crossover Strategy
Classic trend-following strategy
"""

import pandas as pd
from app.core.strategy.base_strategy import BaseStrategy
from app.indicators.trend import sma, ema


class MACrossoverStrategy(BaseStrategy):
    """
    Moving Average Crossover Strategy

    Buys when fast MA crosses above slow MA
    Sells when fast MA crosses below slow MA
    """

    def populate_indicators(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        """Add moving averages"""

        # Get periods from config
        fast_period = self.config.get("fast_period", 10)
        slow_period = self.config.get("slow_period", 30)
        ma_type = self.config.get("ma_type", "sma")  # sma or ema

        # Calculate MAs
        if ma_type == "ema":
            dataframe["ma_fast"] = ema(dataframe["close"], fast_period)
            dataframe["ma_slow"] = ema(dataframe["close"], slow_period)
        else:
            dataframe["ma_fast"] = sma(dataframe["close"], fast_period)
            dataframe["ma_slow"] = sma(dataframe["close"], slow_period)

        return dataframe

    def populate_entry_signals(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        """Generate buy signals on crossover"""

        dataframe["enter_long"] = (
            (dataframe["ma_fast"] > dataframe["ma_slow"]) &
            (dataframe["ma_fast"].shift(1) <= dataframe["ma_slow"].shift(1))
        )

        return dataframe

    def populate_exit_signals(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        """Generate sell signals on crossunder"""

        dataframe["exit_long"] = (
            (dataframe["ma_fast"] < dataframe["ma_slow"]) &
            (dataframe["ma_fast"].shift(1) >= dataframe["ma_slow"].shift(1))
        )

        return dataframe
