"""
Base Strategy Class
All trading strategies inherit from this
Inspired by Freqtrade, Jesse, and Backtrader
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
import pandas as pd
from dataclasses import dataclass
from enum import Enum


class Signal(Enum):
    """Trading signals"""
    BUY = "buy"
    SELL = "sell"
    HOLD = "hold"


@dataclass
class TradeSignal:
    """Trade signal with metadata"""
    signal: Signal
    symbol: str
    price: float
    quantity: float
    confidence: float = 1.0
    reason: str = ""
    timestamp: Optional[pd.Timestamp] = None


class BaseStrategy(ABC):
    """
    Abstract base class for all trading strategies

    Subclasses must implement:
    - populate_indicators(): Add indicators to dataframe
    - populate_entry_signals(): Generate entry signals
    - populate_exit_signals(): Generate exit signals
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize strategy

        Args:
            config: Strategy configuration
        """
        self.config = config
        self.name = config.get("name", self.__class__.__name__)
        self.timeframe = config.get("timeframe", "1h")
        self.stake_amount = config.get("stake_amount", 100.0)
        self.stop_loss = config.get("stop_loss", 0.05)
        self.take_profit = config.get("take_profit", 0.10)

    @abstractmethod
    def populate_indicators(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        """
        Add indicators to dataframe

        Args:
            dataframe: OHLCV dataframe

        Returns:
            Dataframe with indicators
        """
        pass

    @abstractmethod
    def populate_entry_signals(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        """
        Generate entry (buy) signals

        Args:
            dataframe: Dataframe with indicators

        Returns:
            Dataframe with 'enter_long' column
        """
        pass

    @abstractmethod
    def populate_exit_signals(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        """
        Generate exit (sell) signals

        Args:
            dataframe: Dataframe with indicators

        Returns:
            Dataframe with 'exit_long' column
        """
        pass

    def analyze(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        """
        Complete strategy analysis pipeline

        Args:
            dataframe: OHLCV dataframe

        Returns:
            Dataframe with indicators and signals
        """
        dataframe = self.populate_indicators(dataframe)
        dataframe = self.populate_entry_signals(dataframe)
        dataframe = self.populate_exit_signals(dataframe)
        return dataframe

    def should_enter(self, dataframe: pd.DataFrame) -> bool:
        """
        Check if should enter position

        Args:
            dataframe: Analyzed dataframe

        Returns:
            True if should enter
        """
        if dataframe.empty or len(dataframe) < 2:
            return False

        latest = dataframe.iloc[-1]
        return latest.get("enter_long", False)

    def should_exit(self, dataframe: pd.DataFrame) -> bool:
        """
        Check if should exit position

        Args:
            dataframe: Analyzed dataframe

        Returns:
            True if should exit
        """
        if dataframe.empty or len(dataframe) < 2:
            return False

        latest = dataframe.iloc[-1]
        return latest.get("exit_long", False)

    def calculate_position_size(
        self,
        current_price: float,
        account_balance: float
    ) -> float:
        """
        Calculate position size based on risk

        Args:
            current_price: Current asset price
            account_balance: Available balance

        Returns:
            Position size
        """
        risk_amount = account_balance * self.stop_loss
        position_size = min(
            self.stake_amount / current_price,
            risk_amount / (current_price * self.stop_loss)
        )
        return position_size

    def __repr__(self):
        return f"<{self.name} ({self.timeframe})>"
