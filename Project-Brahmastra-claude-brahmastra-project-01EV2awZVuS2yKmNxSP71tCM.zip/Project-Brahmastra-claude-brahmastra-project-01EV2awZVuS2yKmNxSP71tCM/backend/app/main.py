"""
Project Brahmastra - Main FastAPI Application
AI-Powered Autonomous Trading Platform
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import pandas as pd
from typing import Dict, Any, List

from app.config import get_settings
from app.database import get_db, init_db
from app.exchanges.exchange_factory import ExchangeFactory
from app.core.strategy.ma_crossover import MACrossoverStrategy
from app.core.backtesting.backtest_engine import BacktestEngine

# Initialize app
app = FastAPI(
    title="Project Brahmastra",
    description="AI-Powered Autonomous Trading Platform",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure properly in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

settings = get_settings()


@app.on_event("startup")
async def startup_event():
    """Initialize on startup"""
    print("🚀 Starting Project Brahmastra...")
    print(f"Environment: {settings.ENVIRONMENT}")

    # Initialize database
    init_db()
    print("✅ Database initialized")


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "Project Brahmastra",
        "version": "1.0.0",
        "description": "AI-Powered Autonomous Trading Platform",
        "status": "operational"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}


# ===== Exchange Endpoints =====

@app.get("/api/v1/exchanges")
async def list_exchanges():
    """List supported exchanges"""
    return {
        "exchanges": ExchangeFactory.list_exchanges()
    }


@app.get("/api/v1/exchanges/{exchange_name}/ticker/{symbol}")
async def get_ticker(exchange_name: str, symbol: str):
    """
    Get ticker for symbol

    Example: /api/v1/exchanges/binance/ticker/BTC/USDT
    """
    try:
        exchange = ExchangeFactory.create(exchange_name, auto_connect=False)
        ticker = exchange.get_ticker(symbol)
        return ticker
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/v1/exchanges/{exchange_name}/ohlcv/{symbol}")
async def get_ohlcv(
    exchange_name: str,
    symbol: str,
    timeframe: str = "1h",
    limit: int = 100
):
    """
    Get OHLCV data

    Example: /api/v1/exchanges/binance/ohlcv/BTC/USDT?timeframe=1h&limit=100
    """
    try:
        exchange = ExchangeFactory.create(exchange_name, auto_connect=False)
        candles = exchange.get_ohlcv(symbol, timeframe, limit)
        return {"data": candles}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ===== Backtest Endpoints =====

@app.post("/api/v1/backtest")
async def run_backtest(request: Dict[str, Any]):
    """
    Run a backtest

    Request body:
    {
        "exchange": "binance",
        "symbol": "BTC/USDT",
        "timeframe": "1h",
        "limit": 1000,
        "strategy": {
            "name": "ma_crossover",
            "fast_period": 10,
            "slow_period": 30
        },
        "initial_capital": 10000
    }
    """
    try:
        # Get data
        exchange_name = request.get("exchange", "binance")
        symbol = request.get("symbol", "BTC/USDT")
        timeframe = request.get("timeframe", "1h")
        limit = request.get("limit", 1000)

        exchange = ExchangeFactory.create(exchange_name, auto_connect=False)
        candles = exchange.get_ohlcv(symbol, timeframe, limit)

        # Convert to DataFrame
        df = pd.DataFrame(candles)

        # Create strategy
        strategy_config = request.get("strategy", {})
        strategy_config["timeframe"] = timeframe

        strategy = MACrossoverStrategy(strategy_config)

        # Run backtest
        initial_capital = request.get("initial_capital", 10000)
        backtest_engine = BacktestEngine(strategy, initial_capital)

        result = backtest_engine.run(df)

        # Return results
        return {
            "success": True,
            "results": {
                "initial_capital": result.initial_capital,
                "final_equity": result.final_equity,
                "total_return": result.total_return,
                "total_trades": result.total_trades,
                "winning_trades": result.winning_trades,
                "losing_trades": result.losing_trades,
                "win_rate": result.win_rate,
                "profit_factor": result.profit_factor,
                "sharpe_ratio": result.sharpe_ratio,
                "max_drawdown": result.max_drawdown,
                "average_win": result.average_win,
                "average_loss": result.average_loss,
            },
            "trades": result.trades[-10:],  # Last 10 trades
            "equity_curve": result.equity_curve[-100:]  # Last 100 points
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ===== Strategy Endpoints =====

@app.get("/api/v1/strategies")
async def list_strategies():
    """List available strategies"""
    return {
        "strategies": [
            {
                "name": "ma_crossover",
                "description": "Moving Average Crossover Strategy",
                "parameters": {
                    "fast_period": {"type": "int", "default": 10},
                    "slow_period": {"type": "int", "default": 30},
                    "ma_type": {"type": "string", "default": "sma", "options": ["sma", "ema"]}
                }
            }
        ]
    }


# ===== Indicator Endpoints =====

@app.post("/api/v1/indicators/calculate")
async def calculate_indicators(request: Dict[str, Any]):
    """
    Calculate indicators on data

    Request body:
    {
        "data": [...],  // OHLCV data
        "indicators": ["sma", "rsi", "macd"]
    }
    """
    try:
        from app.indicators import sma, rsi, macd

        data = request.get("data", [])
        if not data:
            raise ValueError("No data provided")

        df = pd.DataFrame(data)

        indicators_to_calc = request.get("indicators", [])
        results = {}

        if "sma" in indicators_to_calc:
            results["sma_20"] = sma(df["close"], 20).tolist()

        if "rsi" in indicators_to_calc:
            results["rsi_14"] = rsi(df["close"], 14).tolist()

        if "macd" in indicators_to_calc:
            macd_line, signal_line, histogram = macd(df["close"])
            results["macd"] = macd_line.tolist()
            results["macd_signal"] = signal_line.tolist()
            results["macd_histogram"] = histogram.tolist()

        return {"success": True, "indicators": results}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
