"""
Exchange Factory
Create exchange instances based on name
"""

from typing import Optional
import ccxt
from app.exchanges.base_exchange import BaseExchange
from app.config import get_settings


class BinanceExchange(BaseExchange):
    """Binance exchange connector"""

    def connect(self) -> bool:
        """Connect to Binance"""
        try:
            self.exchange = ccxt.binance({
                "apiKey": self.api_key,
                "secret": self.api_secret,
                "enableRateLimit": True,
            })
            # Test connection
            self.exchange.fetch_ticker("BTC/USDT")
            return True
        except Exception as e:
            print(f"Error connecting to Binance: {e}")
            return False


class CoinbaseExchange(BaseExchange):
    """Coinbase Pro exchange connector"""

    def connect(self) -> bool:
        """Connect to Coinbase Pro"""
        try:
            self.exchange = ccxt.coinbasepro({
                "apiKey": self.api_key,
                "secret": self.api_secret,
                "enableRateLimit": True,
            })
            self.exchange.fetch_ticker("BTC/USD")
            return True
        except Exception as e:
            print(f"Error connecting to Coinbase: {e}")
            return False


class AlpacaExchange(BaseExchange):
    """Alpaca exchange connector for stocks"""

    def connect(self) -> bool:
        """Connect to Alpaca"""
        try:
            # Alpaca uses different library, but we simulate CCXT-like interface
            self.exchange = ccxt.alpaca({
                "apiKey": self.api_key,
                "secret": self.api_secret,
                "enableRateLimit": True,
            })
            return True
        except Exception as e:
            print(f"Error connecting to Alpaca: {e}")
            return False


class ExchangeFactory:
    """
    Factory for creating exchange instances
    Inspired by Blankly's exchange abstraction
    """

    _exchanges = {
        "binance": BinanceExchange,
        "coinbase": CoinbaseExchange,
        "alpaca": AlpacaExchange,
    }

    @classmethod
    def create(
        cls,
        exchange_name: str,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        auto_connect: bool = True
    ) -> BaseExchange:
        """
        Create exchange instance

        Args:
            exchange_name: Name of exchange
            api_key: API key (optional, loads from config if not provided)
            api_secret: API secret (optional)
            auto_connect: Auto-connect on creation

        Returns:
            Exchange instance

        Raises:
            ValueError: If exchange not supported
        """
        exchange_name = exchange_name.lower()

        if exchange_name not in cls._exchanges:
            raise ValueError(f"Exchange {exchange_name} not supported")

        # Load from config if not provided
        if not api_key:
            settings = get_settings()
            if exchange_name == "binance":
                api_key = settings.BINANCE_API_KEY
                api_secret = settings.BINANCE_API_SECRET
            elif exchange_name == "coinbase":
                api_key = settings.COINBASE_API_KEY
                api_secret = settings.COINBASE_API_SECRET
            elif exchange_name == "alpaca":
                api_key = settings.ALPACA_API_KEY
                api_secret = settings.ALPACA_API_SECRET

        exchange_class = cls._exchanges[exchange_name]
        exchange = exchange_class(api_key, api_secret)

        if auto_connect and api_key:
            exchange.connect()

        return exchange

    @classmethod
    def list_exchanges(cls) -> list:
        """List supported exchanges"""
        return list(cls._exchanges.keys())
