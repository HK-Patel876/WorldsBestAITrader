"""
Base Exchange Interface
Abstract base for all exchange connectors
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
import ccxt
from datetime import datetime


class BaseExchange(ABC):
    """
    Base exchange interface inspired by Blankly and Hummingbot
    Provides unified API across all exchanges
    """

    def __init__(self, api_key: Optional[str] = None, api_secret: Optional[str] = None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.exchange: Optional[ccxt.Exchange] = None

    @abstractmethod
    def connect(self) -> bool:
        """Connect to exchange"""
        pass

    def get_ticker(self, symbol: str) -> Dict[str, Any]:
        """
        Get current ticker for symbol

        Args:
            symbol: Trading pair (e.g., 'BTC/USDT')

        Returns:
            Ticker data
        """
        if not self.exchange:
            raise ConnectionError("Exchange not connected")

        ticker = self.exchange.fetch_ticker(symbol)
        return {
            "symbol": symbol,
            "price": ticker.get("last"),
            "bid": ticker.get("bid"),
            "ask": ticker.get("ask"),
            "volume_24h": ticker.get("quoteVolume"),
            "change_24h": ticker.get("percentage"),
            "timestamp": ticker.get("timestamp"),
        }

    def get_ohlcv(
        self,
        symbol: str,
        timeframe: str = "1h",
        limit: int = 100,
        since: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get OHLCV candle data

        Args:
            symbol: Trading pair
            timeframe: Candle timeframe (1m, 5m, 1h, 1d, etc.)
            limit: Number of candles
            since: Timestamp to start from

        Returns:
            List of OHLCV candles
        """
        if not self.exchange:
            raise ConnectionError("Exchange not connected")

        ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe, since, limit)

        return [
            {
                "time": datetime.fromtimestamp(candle[0] / 1000),
                "open": candle[1],
                "high": candle[2],
                "low": candle[3],
                "close": candle[4],
                "volume": candle[5],
            }
            for candle in ohlcv
        ]

    def get_orderbook(self, symbol: str, limit: int = 20) -> Dict[str, Any]:
        """
        Get order book

        Args:
            symbol: Trading pair
            limit: Depth limit

        Returns:
            Order book data
        """
        if not self.exchange:
            raise ConnectionError("Exchange not connected")

        orderbook = self.exchange.fetch_order_book(symbol, limit)

        return {
            "symbol": symbol,
            "bids": orderbook["bids"],
            "asks": orderbook["asks"],
            "timestamp": orderbook.get("timestamp"),
        }

    def place_market_order(
        self,
        symbol: str,
        side: str,
        amount: float
    ) -> Dict[str, Any]:
        """
        Place market order

        Args:
            symbol: Trading pair
            side: 'buy' or 'sell'
            amount: Order amount

        Returns:
            Order details
        """
        if not self.exchange:
            raise ConnectionError("Exchange not connected")

        order = self.exchange.create_market_order(symbol, side, amount)
        return self._normalize_order(order)

    def place_limit_order(
        self,
        symbol: str,
        side: str,
        amount: float,
        price: float
    ) -> Dict[str, Any]:
        """
        Place limit order

        Args:
            symbol: Trading pair
            side: 'buy' or 'sell'
            amount: Order amount
            price: Limit price

        Returns:
            Order details
        """
        if not self.exchange:
            raise ConnectionError("Exchange not connected")

        order = self.exchange.create_limit_order(symbol, side, amount, price)
        return self._normalize_order(order)

    def cancel_order(self, order_id: str, symbol: str) -> bool:
        """
        Cancel an order

        Args:
            order_id: Order ID
            symbol: Trading pair

        Returns:
            Success status
        """
        if not self.exchange:
            raise ConnectionError("Exchange not connected")

        try:
            self.exchange.cancel_order(order_id, symbol)
            return True
        except Exception as e:
            print(f"Error cancelling order: {e}")
            return False

    def get_balance(self) -> Dict[str, float]:
        """
        Get account balance

        Returns:
            Balance by currency
        """
        if not self.exchange:
            raise ConnectionError("Exchange not connected")

        balance = self.exchange.fetch_balance()
        return {
            currency: {
                "free": balance[currency]["free"],
                "used": balance[currency]["used"],
                "total": balance[currency]["total"],
            }
            for currency in balance
            if balance[currency]["total"] > 0
        }

    def _normalize_order(self, order: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize order data across exchanges"""
        return {
            "id": order.get("id"),
            "symbol": order.get("symbol"),
            "type": order.get("type"),
            "side": order.get("side"),
            "price": order.get("price"),
            "amount": order.get("amount"),
            "filled": order.get("filled"),
            "remaining": order.get("remaining"),
            "status": order.get("status"),
            "timestamp": order.get("timestamp"),
        }
