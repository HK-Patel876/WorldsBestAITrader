"""
Trade Model
"""

from sqlalchemy import Column, String, Float, DateTime, ForeignKey, Integer, Text
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.sql import func
import uuid
from app.database import Base


class Trade(Base):
    """Trade model for completed trades"""

    __tablename__ = "trades"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    strategy_id = Column(UUID(as_uuid=True), ForeignKey("strategies.id"))

    # Trade details
    symbol = Column(String(20), nullable=False, index=True)
    side = Column(String(10), nullable=False)  # buy, sell

    # Entry
    entry_price = Column(Float, nullable=False)
    entry_quantity = Column(Float, nullable=False)
    entry_time = Column(DateTime(timezone=True), nullable=False)
    entry_fee = Column(Float, default=0.0)

    # Exit
    exit_price = Column(Float)
    exit_quantity = Column(Float)
    exit_time = Column(DateTime(timezone=True))
    exit_fee = Column(Float, default=0.0)
    exit_reason = Column(String(50))  # take_profit, stop_loss, signal, manual

    # PnL
    gross_pnl = Column(Float)
    net_pnl = Column(Float)
    pnl_percentage = Column(Float)

    # Risk metrics
    risk_reward_ratio = Column(Float)
    max_adverse_excursion = Column(Float)  # MAE
    max_favorable_excursion = Column(Float)  # MFE

    # Duration
    duration_seconds = Column(Integer)

    # Metadata
    notes = Column(Text)
    tags = Column(ARRAY(Text))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def __repr__(self):
        return f"<Trade {self.symbol} {self.side} @ {self.entry_price}>"
