"""
Strategy Model
"""

from sqlalchemy import Column, String, Integer, Float, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID, ARRAY, JSONB
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import uuid
from app.database import Base


class Strategy(Base):
    """Strategy model for trading strategies"""

    __tablename__ = "strategies"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # Basic info
    name = Column(String(100), nullable=False)
    description = Column(Text)
    type = Column(String(50), nullable=False)  # ma_crossover, rsi, ml_lstm, etc.
    status = Column(String(20), default="draft")  # draft, testing, live, paused, archived

    # Configuration
    config = Column(JSONB, nullable=False)  # Strategy parameters
    timeframe = Column(String(10))  # 1m, 5m, 1h, 1d
    symbols = Column(ARRAY(Text))  # Trading symbols

    # Performance metrics
    total_trades = Column(Integer, default=0)
    winning_trades = Column(Integer, default=0)
    total_pnl = Column(Float, default=0.0)
    sharpe_ratio = Column(Float)
    max_drawdown = Column(Float)

    # Risk management
    max_position_size = Column(Float)
    stop_loss_pct = Column(Float)
    take_profit_pct = Column(Float)

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    activated_at = Column(DateTime(timezone=True))
    deactivated_at = Column(DateTime(timezone=True))

    def __repr__(self):
        return f"<Strategy {self.name} ({self.type})>"
