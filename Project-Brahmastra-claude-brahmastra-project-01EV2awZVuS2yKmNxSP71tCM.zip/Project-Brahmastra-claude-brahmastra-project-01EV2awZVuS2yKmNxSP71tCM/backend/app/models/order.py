"""
Order Model
"""

from sqlalchemy import Column, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
import uuid
from app.database import Base


class Order(Base):
    """Order model for tracking orders"""

    __tablename__ = "orders"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    strategy_id = Column(UUID(as_uuid=True), ForeignKey("strategies.id"))

    # Order details
    exchange_order_id = Column(String(100), index=True)
    symbol = Column(String(20), nullable=False, index=True)
    side = Column(String(10), nullable=False)  # buy, sell
    type = Column(String(20), nullable=False)  # market, limit, stop_loss, etc.
    status = Column(String(20), nullable=False, index=True)  # pending, open, filled, etc.

    # Quantities and prices
    quantity = Column(Float, nullable=False)
    filled_quantity = Column(Float, default=0.0)
    price = Column(Float)  # Limit price
    stop_price = Column(Float)  # Stop price
    average_fill_price = Column(Float)

    # Fees
    fee = Column(Float, default=0.0)
    fee_currency = Column(String(10))

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    submitted_at = Column(DateTime(timezone=True))
    filled_at = Column(DateTime(timezone=True))
    cancelled_at = Column(DateTime(timezone=True))

    # Additional info
    time_in_force = Column(String(10), default="GTC")
    reduce_only = Column(String, default=False)
    client_order_id = Column(String(100))
    error_message = Column(Text)

    def __repr__(self):
        return f"<Order {self.symbol} {self.side} {self.quantity} @ {self.price}>"
