"""
Backtest Model
"""

from sqlalchemy import Column, String, Float, DateTime, ForeignKey, Integer, Text
from sqlalchemy.dialects.postgresql import UUID, ARRAY, JSONB
from sqlalchemy.sql import func
import uuid
from app.database import Base


class Backtest(Base):
    """Backtest model for strategy backtests"""

    __tablename__ = "backtests"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    strategy_id = Column(UUID(as_uuid=True), ForeignKey("strategies.id"))

    # Backtest parameters
    name = Column(String(100))
    symbols = Column(ARRAY(Text), nullable=False)
    timeframe = Column(String(10), nullable=False)
    start_date = Column(DateTime(timezone=True), nullable=False)
    end_date = Column(DateTime(timezone=True), nullable=False)
    initial_capital = Column(Float, nullable=False)

    # Configuration
    strategy_config = Column(JSONB, nullable=False)
    commission_rate = Column(Float, default=0.001)
    slippage_rate = Column(Float, default=0.0005)

    # Results
    status = Column(String(20), default="pending", index=True)
    total_trades = Column(Integer)
    winning_trades = Column(Integer)
    losing_trades = Column(Integer)
    win_rate = Column(Float)

    # Performance metrics
    total_return = Column(Float)
    annual_return = Column(Float)
    sharpe_ratio = Column(Float)
    sortino_ratio = Column(Float)
    max_drawdown = Column(Float)
    max_drawdown_duration = Column(Integer)

    # Additional metrics
    profit_factor = Column(Float)
    average_win = Column(Float)
    average_loss = Column(Float)
    largest_win = Column(Float)
    largest_loss = Column(Float)

    # Results storage
    results_s3_key = Column(String(255))
    equity_curve = Column(JSONB)

    # Execution
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    duration_seconds = Column(Integer)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def __repr__(self):
        return f"<Backtest {self.name} ({self.status})>"
